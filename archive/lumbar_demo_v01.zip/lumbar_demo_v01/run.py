#!/usr/bin/env python3
"""Run the local browser console: python run.py"""
from __future__ import annotations

import argparse
from functools import partial
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import sys
import threading
from urllib.parse import urlsplit
import webbrowser

from lumbar.service import DemoService, dumps, list_serial_ports


ROOT = Path(__file__).resolve().parent


def strict_json(data):
    def reject(value):
        raise ValueError("不接受非有限数值：" + value)
    return json.loads(data, parse_constant=reject)


class Handler(BaseHTTPRequestHandler):
    server_version = "LumbarLab/0.1"

    def __init__(self, *args, service=None, **kwargs):
        self.service = service
        super().__init__(*args, **kwargs)

    def log_message(self, format, *args):
        if len(args) > 1 and str(args[1]).startswith(("4", "5")):
            super().log_message(format, *args)

    def send_body(self, body, status=200, mime="application/json; charset=utf-8", filename=None):
        self.send_response(status)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        if filename:
            self.send_header("Content-Disposition", 'attachment; filename="' + filename + '"')
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def json(self, payload, status=200):
        self.send_body(dumps(payload).encode("utf-8"), status)

    def do_GET(self):
        path = urlsplit(self.path).path
        try:
            if path == "/api/state":
                self.json(self.service.state())
            elif path == "/api/sessions":
                self.json(self.service.sessions())
            elif path == "/api/ports":
                self.json(list_serial_ports())
            elif path.startswith("/api/download/"):
                session_id = path.removeprefix("/api/download/")
                self.send_body(self.service.download(session_id), mime="application/zip", filename=session_id + ".zip")
            else:
                assets = {"/": ("index.html", "text/html; charset=utf-8"),
                          "/index.html": ("index.html", "text/html; charset=utf-8"),
                          "/style.css": ("style.css", "text/css; charset=utf-8"),
                          "/app.js": ("app.js", "application/javascript; charset=utf-8")}
                if path not in assets:
                    self.json({"ok": False, "error": "页面不存在"}, 404)
                    return
                name, mime = assets[path]
                self.send_body((ROOT / "web" / name).read_bytes(), mime=mime)
        except (ValueError, OSError) as exc:
            self.json({"ok": False, "error": str(exc)}, 400)

    def do_POST(self):
        if urlsplit(self.path).path != "/api/action":
            self.json({"ok": False, "error": "接口不存在"}, 404)
            return
        origin = self.headers.get("Origin")
        if origin and urlsplit(origin).netloc != self.headers.get("Host"):
            self.json({"ok": False, "error": "仅允许当前本地页面操作"}, 403)
            return
        if not self.headers.get("Content-Type", "").startswith("application/json"):
            self.json({"ok": False, "error": "请使用 JSON 请求"}, 415)
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= 65536:
                raise ValueError("请求长度无效")
            payload = strict_json(self.rfile.read(length).decode("utf-8"))
            state = self.service.action(payload)
            self.json({"ok": True, "state": state})
        except (ValueError, TypeError, KeyError, OSError) as exc:
            self.json({"ok": False, "error": str(exc)}, 400)


def main():
    parser = argparse.ArgumentParser(description="腰靠实验台：模拟、串口只读与记录回放")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--strictPort", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    if sys.version_info < (3, 10):
        raise SystemExit("请安装 Python 3.10 或更新版本")
    service = DemoService(ROOT)
    try:
        server = ThreadingHTTPServer((args.host, args.port), partial(Handler, service=service))
    except OSError as exc:
        raise SystemExit(f"端口无法启动：{exc}。可尝试 python run.py --port 8766") from exc
    url = f"http://127.0.0.1:{args.port}/"
    print("腰靠实验台 v0.1 · 模拟设备已就绪", flush=True)
    print("Local: " + url, flush=True)
    print("真实串口为只读；当前程序不会发送真实电机指令。按 Ctrl+C 退出。", flush=True)
    service.start()
    if not args.no_browser:
        timer = threading.Timer(0.6, lambda: webbrowser.open(url))
        timer.daemon = True
        timer.start()
    try:
        server.serve_forever(poll_interval=0.2)
    except KeyboardInterrupt:
        pass
    finally:
        service.close()
        server.server_close()


if __name__ == "__main__":
    main()
