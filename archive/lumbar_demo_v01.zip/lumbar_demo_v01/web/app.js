"use strict";

(() => {
  const $ = (id) => document.getElementById(id);
  const ZONE_NAMES = ["座面前", "座面前", "座面后", "座面后", "腰托", "腰托", "腰托", "上靠背"];
  const ACTIONS = { extend: "前顶", retract: "回退", hold: "保持", stop: "停止", stopped: "停止", unknown: "未知" };
  const MODES = { manual: "手动模式", auto: "自动模式", paused: "已暂停" };
  const ORIGINS = { mock: "模拟数据", simulated: "模拟数据", simulation: "模拟数据", synthetic: "模拟数据", serial: "串口读数", serial_stream: "串口读数", hardware_stream: "串口读数", hardware_measured: "硬件读数", replay: "历史回放", unverified: "来源未核实" };
  let latest = null;
  let history = [];
  let lastSample = "";
  let sourceIdentity = "";
  let requestRunning = false;
  let toastTimer = null;
  let sessionSignature = "";
  let eventSignature = "";
  let matrixSignature = "";
  let lastSessionPoll = 0;
  let configLoaded = false;
  let recordingWasActive = false;

  const finite = (value) => typeof value === "number" && Number.isFinite(value);
  const numberText = (value, decimals = 0) => finite(value) ? value.toFixed(decimals) : "—";
  const setText = (id, value) => { $(id).textContent = value; };
  const show = (id, visible) => { $(id).hidden = !visible; };
  const elapsed = (seconds) => {
    if (!finite(seconds)) return "00:00";
    const s = Math.max(0, Math.floor(seconds));
    const minutes = Math.floor(s / 60);
    return `${String(minutes).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
  };

  function eventTime(value) {
    if (typeof value === "string") {
      const date = new Date(value);
      return Number.isFinite(date.getTime()) ? date.toLocaleTimeString("zh-CN", { hour12: false }) : value.slice(0, 12);
    }
    if (finite(value) && value > 1e9) return new Date(value * 1000).toLocaleTimeString("zh-CN", { hour12: false });
    if (finite(value)) return `${value.toFixed(1)} s`;
    return "—";
  }

  function notify(message, error = false) {
    clearTimeout(toastTimer);
    setText("toast", message);
    $("toast").classList.toggle("error", error);
    show("toast", true);
    toastTimer = setTimeout(() => show("toast", false), error ? 6500 : 3500);
  }

  async function fetchJson(url, options = {}) {
    const response = await fetch(url, { cache: "no-store", ...options });
    let body;
    try { body = await response.json(); } catch (_) { throw new Error("本地服务返回了无法识别的数据，请检查终端窗口。"); }
    if (!response.ok || body.ok === false) throw new Error(body.error || `请求未完成（${response.status}）`);
    return body;
  }

  async function command(action, values = {}, message = "") {
    try {
      const result = await fetchJson("/api/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, ...values })
      });
      if (action === "source") {
        sourceIdentity = "";
        history = [];
        lastSample = "";
      }
      if (action === "calibrate") {
        history = [];
        lastSample = "";
      }
      if (result.state) render(result.state);
      if (message) notify(message);
      return true;
    } catch (error) {
      notify(error.message || "操作未完成。", true);
      return false;
    }
  }

  function sourceLabel(kind) {
    return { mock: "模拟设备", serial: "真实串口 · 只读", replay: "历史回放" }[kind] || "等待设备";
  }

  function createReadouts() {
    const fragment = document.createDocumentFragment();
    for (let id = 1; id <= 8; id++) {
      const item = document.createElement("div");
      item.className = `zone-value${id >= 5 && id <= 7 ? " lumbar" : ""}`;
      item.id = `zoneValue${id}`;
      const name = document.createElement("span");
      name.textContent = `${ZONE_NAMES[id - 1]} ${id}`;
      const index = document.createElement("span");
      index.className = "zone-id";
      index.textContent = `Z${id}`;
      const value = document.createElement("strong");
      value.id = `zoneNumber${id}`;
      value.textContent = "—";
      item.append(name, index, value);
      fragment.append(item);
    }
    $("zoneReadouts").append(fragment);
  }

  function renderZones(zones) {
    const items = Array.isArray(zones) ? zones : [];
    const scaleMax = Math.max(80, ...items.filter(z => z && z.valid && finite(z.value)).map(z => z.value));
    for (let id = 1; id <= 8; id++) {
      const zone = items.find((item) => item && Number(item.id) === id);
      const ok = Boolean(zone && zone.valid && finite(zone.value));
      const value = ok ? zone.value : null;
      setText(`zoneNumber${id}`, numberText(value, 1));
      $(`zoneValue${id}`).title = ok ? `${zone.label || ZONE_NAMES[id - 1]}：${value.toFixed(2)}，相对电信号，非牛顿` : "当前没有已确认的有效测区读数";
      const point = document.querySelector(`.zone-point[data-zone="${id}"]`);
      point.classList.toggle("unavailable", !ok);
      if (ok) {
        const strength = Math.max(0, Math.min(1, value / scaleMax));
        point.querySelector(".zone-core").style.fill = `hsl(${112 + strength * 30} 26% ${84 - strength * 42}%)`;
        point.querySelector(".zone-core").style.stroke = `hsl(128 24% ${70 - strength * 28}%)`;
        point.querySelector(".zone-halo").style.opacity = String(0.04 + strength * 0.12);
        point.querySelector(".zone-number").style.fill = strength > 0.6 ? "#f0f6e8" : "#3f6245";
      } else {
        point.querySelector(".zone-core").style.removeProperty("fill");
        point.querySelector(".zone-core").style.removeProperty("stroke");
        point.querySelector(".zone-halo").style.removeProperty("opacity");
        point.querySelector(".zone-number").style.removeProperty("fill");
      }
    }
  }

  function renderEvents(events) {
    const items = (Array.isArray(events) ? events : []).slice(-16).reverse();
    const signature = JSON.stringify(items);
    if (signature === eventSignature) return;
    eventSignature = signature;
    $("eventList").replaceChildren();
    if (!items.length) {
      const empty = document.createElement("li");
      empty.className = "empty-list";
      empty.textContent = "关键操作会显示在这里。";
      $("eventList").append(empty);
      return;
    }
    for (const event of items) {
      const item = document.createElement("li");
      item.className = `event-item${event.kind === "feedback" ? " feedback" : ""}`;
      const stamp = document.createElement("time");
      stamp.textContent = eventTime(event.time);
      const dot = document.createElement("span");
      dot.className = "event-dot";
      const text = document.createElement("span");
      text.textContent = event.label || event.kind || "事件";
      item.append(stamp, dot, text);
      $("eventList").append(item);
    }
  }

  function updateEnabled(state) {
    const source = state.source || {};
    const ctrl = state.controller || {};
    const recording = Boolean(state.recording && state.recording.active);
    const replay = source.kind === "replay";
    const mock = source.kind === "mock";
    const canMove = mock && Boolean(state.motor && state.motor.can_execute);
    $("manualExtend").disabled = !canMove;
    $("manualRetract").disabled = !canMove;
    $("manualStop").disabled = !canMove;
    $("calibrate").disabled = replay || !ctrl.reference_ready || ctrl.mode === "auto";
    $("autoMode").disabled = replay || !ctrl.reference || !source.connected || ctrl.mode === "auto";
    $("pauseMode").disabled = replay;
    $("recordStart").disabled = replay || recording || !source.connected;
    $("recordStop").disabled = !recording;
    $("participant").disabled = recording || replay;
    $("switchSource").disabled = recording;
    $("sourceSelect").disabled = recording;
    $("connectSerial").disabled = recording;
    $("captureZero").disabled = source.kind !== "serial" || !source.connected || !$("unloadedCheck").checked;
    $("unloadedCheck").disabled = source.kind !== "serial";
    $("saveConfig").disabled = replay;
    document.querySelectorAll("#configForm input").forEach((input) => { input.disabled = replay; });
    document.querySelectorAll("[data-feedback]").forEach((button) => { button.disabled = replay; });
    document.querySelectorAll("[data-scenario]").forEach((button) => { button.disabled = !mock; });
    document.querySelectorAll(".session-replay").forEach((button) => { button.disabled = recording; });
    setText("autoMode", source.kind === "serial" ? "查看自动建议" : ctrl.mode === "auto" ? "自动调节中" : "开启自动");
    setText("autoHint", source.kind === "serial" ? "计算控制建议，当前不会驱动真实电机" : "围绕参考范围，前顶、保持或回退");
    setText("actuatorNotice", mock ? "仅作用于模拟设备" : replay ? "历史状态，仅供查看" : "真实电机接口尚未接入");
    setText("calibrationHint", ctrl.mode === "auto" ? "如需重新设定，先暂停自动调节" : ctrl.reference_ready ? "读数已稳定，可以记录当前支撑" : "保持身体和腰托稳定，等待可用的接触读数");
  }

  function render(state) {
    if (!state || typeof state !== "object") return;
    latest = state;
    $("serverDot").className = "status-dot online";
    setText("serverLabel", "本地服务已连接");
    show("connectionError", false);
    const source = state.source || {};
    const ctrl = state.controller || {};
    const stats = state.stats || {};
    const motor = state.motor || {};
    const recording = state.recording || {};
    const replay = state.replay || {};
    const identity = `${source.kind || "unknown"}:${replay.session_id || ""}`;
    if (identity !== sourceIdentity) {
      sourceIdentity = identity;
      history = [];
      lastSample = "";
      matrixSignature = "";
      configLoaded = false;
      $("unloadedCheck").checked = false;
    }
    const label = sourceLabel(source.kind);
    setText("sourceBadge", label);
    $("sourceBadge").className = `badge ${source.kind === "mock" ? "badge-sim" : source.kind === "replay" ? "badge-replay" : "badge-live"}`;
    setText("sourceName", source.label || label);
    const fallback = source.kind === "mock" ? "合成输入与模拟执行器，用于演练完整软件流程" : source.kind === "serial" ? "正在接收硬件数据；电机指令未连接" : "保留原始记录，仅查看历史响应";
    setText("sourceDetail", source.detail || fallback);
    if (document.activeElement !== $("sourceSelect") && source.kind) $("sourceSelect").value = source.kind;
    show("replayBanner", source.kind === "replay");
    setText("replayProgress", `${replay.index || 0} / ${replay.count || 0} 帧${replay.ended ? " · 已到记录末尾" : ""}`);
    show("scenarioPanel", source.kind === "mock");
    setText("modeBadge", source.kind === "replay" ? "历史控制状态" : MODES[ctrl.mode] || "等待控制器");
    $("modeBadge").className = `badge ${ctrl.mode === "auto" ? "badge-live" : "badge-neutral"}`;
    setText("supportRatio", numberText(ctrl.support_ratio, 2));
    setText("referenceStatus", ctrl.reference ? `允许范围 ${numberText(ctrl.band && ctrl.band.lower, 2)}—${numberText(ctrl.band && ctrl.band.upper, 2)} ×` : "尚未设定个人参考");
    setText("actionTitle", source.kind === "mock" ? "模拟执行动作" : source.kind === "replay" ? "历史控制建议" : "当前控制建议");
    const displayedAction = source.kind === "mock" ? motor.applied_action || ctrl.action : ctrl.action;
    setText("currentAction", ACTIONS[displayedAction] || "待机");
    setText("positionValue", motor.position_origin === "simulated" && finite(motor.position_fraction) ? `模拟伸出量 ${Math.round(motor.position_fraction * 100)}%` : "实际伸出位置未知");
    setText("frameRate", numberText(stats.rate_hz, 1));
    setText("frameAge", finite(stats.frame_age_s) ? `距上一帧 ${stats.frame_age_s.toFixed(2)} 秒` : "尚无有效帧");
    setText("stateLabel", ctrl.state_label || "待机");
    setText("stateReason", ctrl.reason || state.message || "");
    const warning = /FAULT|STALE|INVALID|LOST|OVER|LIMIT|ABSENT|TIMEOUT|MISSING/i.test(ctrl.state || "");
    $("controllerStatus").classList.toggle("warning", warning);
    renderZones(state.zones);
    setText("recordBadge", recording.active ? "正在记录" : "未记录");
    $("recordBadge").className = `badge ${recording.active ? "badge-record" : "badge-neutral"}`;
    setText("recordDuration", elapsed(recording.elapsed_s));
    setText("recordFrames", `${recording.frame_count || 0} 帧`);
    setText("recordHint", recording.active ? `来源：${sourceLabel(source.kind)} · 不自动生成姿态真值` : "同时保存数据、控制建议、参数与反馈");
    if (recordingWasActive && !recording.active) refreshSessions();
    recordingWasActive = Boolean(recording.active);
    document.querySelectorAll("[data-scenario]").forEach((button) => {
      const selected = state.mock && button.dataset.scenario === state.mock.scenario;
      button.classList.toggle("selected", Boolean(selected));
      button.setAttribute("aria-pressed", selected ? "true" : "false");
    });
    if (!configLoaded && ctrl.config) {
      for (const input of document.querySelectorAll("#configForm input")) {
        if (finite(ctrl.config[input.name])) input.value = ctrl.config[input.name];
      }
      configLoaded = true;
    }
    renderEvents(state.events);
    const sampleKey = source.kind === "replay" ? `replay:${replay.index}` : `${source.kind}:${stats.frames}`;
    if (sampleKey !== lastSample) {
      lastSample = sampleKey;
      const fresh = !finite(stats.frame_age_s) || stats.frame_age_s <= (ctrl.config && ctrl.config.stale_s || 0.4);
      history.push({ time: Date.now(), value: fresh && finite(ctrl.support_ratio) ? ctrl.support_ratio : null });
    }
    const cutoff = Date.now() - 60000;
    history = history.filter((point) => point.time >= cutoff).slice(-1000);
    show("chartEmpty", !history.some((point) => finite(point.value)));
    updateEnabled(state);
    drawChart();
    drawMatrix(state.matrix);
  }

  function prepareCanvas(canvas) {
    const rect = canvas.getBoundingClientRect();
    if (!rect.width || !rect.height) return null;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const width = Math.round(rect.width * dpr);
    const height = Math.round(rect.height * dpr);
    if (canvas.width !== width || canvas.height !== height) { canvas.width = width; canvas.height = height; }
    const context = canvas.getContext("2d");
    context.setTransform(dpr, 0, 0, dpr, 0, 0);
    context.clearRect(0, 0, rect.width, rect.height);
    return { context, width: rect.width, height: rect.height };
  }

  function drawChart() {
    const prepared = prepareCanvas($("supportChart"));
    if (!prepared) return;
    const { context: ctx, width, height } = prepared;
    const left = 32, right = 8, top = 10, bottom = 24;
    const plotWidth = width - left - right, plotHeight = height - top - bottom;
    if (plotWidth <= 0 || plotHeight <= 0) return;
    const band = latest && latest.controller && latest.controller.band || { lower: 0.88, upper: 1.16 };
    const values = history.filter((point) => finite(point.value)).map((point) => point.value);
    const yMax = Math.max(1.6, Math.ceil(Math.max(0, ...values) * 5) / 5);
    const y = (value) => top + plotHeight * (1 - value / yMax);
    const now = Date.now();
    const x = (time) => left + Math.max(0, Math.min(1, (time - now + 60000) / 60000)) * plotWidth;
    if (latest && latest.controller && latest.controller.reference && finite(band.lower) && finite(band.upper)) {
      ctx.fillStyle = "#e9f0df";
      ctx.fillRect(left, y(band.upper), plotWidth, y(band.lower) - y(band.upper));
      ctx.setLineDash([3, 5]);
      ctx.strokeStyle = "#b0c69f";
      ctx.lineWidth = 0.8;
      ctx.beginPath(); ctx.moveTo(left, y(1)); ctx.lineTo(width - right, y(1)); ctx.stroke();
      ctx.setLineDash([]);
    }
    ctx.font = "9px Consolas, monospace";
    ctx.textAlign = "right";
    ctx.textBaseline = "middle";
    for (let i = 0; i <= 4; i++) {
      const v = yMax * i / 4;
      const py = y(v);
      ctx.strokeStyle = "#e8ece2";
      ctx.lineWidth = 0.6;
      ctx.beginPath(); ctx.moveTo(left, py); ctx.lineTo(width - right, py); ctx.stroke();
      ctx.fillStyle = "#9eab93";
      ctx.fillText(v.toFixed(1), left - 8, py);
    }
    ctx.textAlign = "center";
    ctx.textBaseline = "top";
    [-60, -45, -30, -15, 0].forEach((value, index) => {
      const px = left + index / 4 * plotWidth;
      ctx.fillStyle = "#a4af9b";
      ctx.fillText(value === 0 ? "现在" : `${value}s`, Math.min(width - 14, Math.max(14, px)), height - 15);
    });
    ctx.lineWidth = 2;
    ctx.lineJoin = "round";
    ctx.lineCap = "round";
    ctx.strokeStyle = "#43806b";
    let connected = false;
    let previous = null;
    ctx.beginPath();
    for (const point of history) {
      if (!finite(point.value) || (previous && point.time - previous.time > 800)) connected = false;
      if (finite(point.value)) {
        if (connected) ctx.lineTo(x(point.time), y(point.value));
        else ctx.moveTo(x(point.time), y(point.value));
        connected = true;
      }
      previous = point;
    }
    ctx.stroke();
    const last = history[history.length - 1];
    if (last && finite(last.value) && now - last.time < 800) {
      ctx.beginPath(); ctx.arc(x(last.time), y(last.value), 3.2, 0, Math.PI * 2); ctx.fillStyle = "#326d59"; ctx.fill();
      ctx.beginPath(); ctx.arc(x(last.time), y(last.value), 6, 0, Math.PI * 2); ctx.strokeStyle = "#326d5935"; ctx.lineWidth = 3; ctx.stroke();
    }
  }

  function drawMatrix(matrix) {
    const hasMatrix = matrix && Array.isArray(matrix.raw) && matrix.raw.length === 256;
    show("matrixEmpty", !hasMatrix);
    setText("matrixLabel", hasMatrix ? "设备 raw · 8 位" : "等待矩阵");
    setText("matrixStatus", hasMatrix ? `空载背景：${matrix.baseline_ready ? "已记录" : "尚未记录"}；八区映射：${matrix.mapping_ready ? "已配置" : "待硬件确认"}。显示矩阵坐标，不代表椅子布局。` : "尚无矩阵数据；未假设八区与行列的对应关系。");
    if (!$("diagnostics").open) return;
    const signature = hasMatrix ? matrix.raw.join(",") : "none";
    if (matrixSignature === signature) return;
    matrixSignature = signature;
    const canvas = $("matrixCanvas");
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (!hasMatrix) return;
    const cell = canvas.width / 16;
    for (let index = 0; index < 256; index++) {
      const value = matrix.raw[index];
      const strength = finite(value) ? Math.max(0, Math.min(1, value / 255)) : 0;
      ctx.fillStyle = `hsl(${105 + strength * 40} 26% ${92 - strength * 59}%)`;
      ctx.fillRect((index % 16) * cell + 0.5, Math.floor(index / 16) * cell + 0.5, cell - 1, cell - 1);
    }
  }

  async function refreshSessions() {
    try {
      const result = await fetchJson("/api/sessions");
      const items = Array.isArray(result.sessions) ? result.sessions : [];
      const signature = JSON.stringify(items);
      if (signature === sessionSignature) return;
      sessionSignature = signature;
      $("sessionList").replaceChildren();
      if (!items.length) {
        const empty = document.createElement("p");
        empty.className = "empty-list";
        empty.textContent = "还没有实验记录。完成一次标定后，可以记录前移与后靠的过程。";
        $("sessionList").append(empty);
      }
      for (const session of items) {
        const item = document.createElement("div"); item.className = "session-item";
        const info = document.createElement("div"); info.className = "session-info";
        const title = document.createElement("strong"); title.textContent = session.id;
        const detail = document.createElement("small");
        const created = session.created_at ? new Date(session.created_at) : null;
        const stamp = created && Number.isFinite(created.getTime()) ? created.toLocaleString("zh-CN", { hour12: false }) : "";
        detail.textContent = `${ORIGINS[session.origin] || session.origin || "来源未标记"} · ${session.frames || 0} 帧${stamp ? ` · ${stamp}` : ""}`;
        info.append(title, detail);
        const controls = document.createElement("div"); controls.className = "session-actions";
        const replay = document.createElement("button"); replay.type = "button"; replay.className = "session-replay"; replay.textContent = "回放";
        replay.disabled = Boolean(latest && latest.recording && latest.recording.active);
        replay.addEventListener("click", () => command("source", { value: "replay", session_id: session.id }, "已打开历史会话，回放不会驱动电机。"));
        const download = document.createElement("a"); download.textContent = "下载"; download.href = `/api/download/${encodeURIComponent(session.id)}`; download.setAttribute("download", "");
        controls.append(replay, download); item.append(info, controls); $("sessionList").append(item);
      }
    } catch (error) {
      if (!latest) return;
      notify(`会话列表读取失败：${error.message}`, true);
    }
  }

  async function refreshPorts() {
    try {
      const result = await fetchJson("/api/ports");
      $("portsList").replaceChildren();
      for (const port of result.ports || []) {
        const option = document.createElement("option"); option.value = port.device; option.textContent = port.description || port.device; $("portsList").append(option);
      }
      if (!result.available) setText("serialHelp", "尚未安装可选串口依赖。请在项目目录运行 python -m pip install pyserial；模拟功能不受影响。");
      else if (!(result.ports || []).length) setText("serialHelp", "当前没有发现串口。连接硬件后重新查找，也可以直接输入端口名。");
      else {
        if (!$("serialPort").value) $("serialPort").value = result.ports[0].device;
        setText("serialHelp", `发现 ${result.ports.length} 个串口。选择实际连接 Nano 的端口；当前仅接收数据。`);
      }
    } catch (error) { notify(error.message, true); }
  }

  async function connectSerial() {
    const port = $("serialPort").value.trim();
    const baud = Number($("serialBaud").value);
    if (!port) { $("diagnostics").open = true; $("serialPort").focus(); notify("请输入或选择实际串口，例如 COM3。", true); return; }
    if (!Number.isInteger(baud) || baud <= 0) { notify("波特率必须为正整数。", true); return; }
    await command("source", { value: "serial", port, baud }, "已请求连接串口；真实电机接口保持未接入。");
  }

  function connectEvents() {
    $("openDiagnostics").addEventListener("click", () => { $("diagnostics").open = true; $("diagnostics").scrollIntoView({ behavior: "smooth", block: "start" }); });
    $("diagnostics").addEventListener("toggle", () => { matrixSignature = ""; if (latest) drawMatrix(latest.matrix); });
    $("switchSource").addEventListener("click", async () => {
      if ($("sourceSelect").value === "serial") {
        $("diagnostics").open = true;
        $("diagnostics").scrollIntoView({ behavior: "smooth", block: "start" });
        if (!$("serialPort").value.trim()) { await refreshPorts(); $("serialPort").focus(); notify("请确认串口与波特率，再点击“连接并只读”。"); }
        else await connectSerial();
      } else if ($("sourceSelect").value === "mock") await command("source", { value: "mock" }, "已切换到模拟设备，个人参考已重置。");
    });
    $("exitReplay").addEventListener("click", () => command("source", { value: "mock" }, "已退出回放，返回模拟设备。"));
    for (const [id, direction] of [["manualExtend", "extend"], ["manualRetract", "retract"]]) {
      $(id).addEventListener("click", async () => {
        if (!latest || latest.source.kind !== "mock") return;
        if (latest.controller.mode !== "manual" && !await command("mode", { value: "manual" })) return;
        await command("manual", { direction });
      });
    }
    $("manualStop").addEventListener("click", () => command("mode", { value: "paused" }, "已停止模拟动作。"));
    $("calibrate").addEventListener("click", () => command("calibrate", {}, "已记住当前支撑，之后可开启自动调节。"));
    $("autoMode").addEventListener("click", () => command("mode", { value: "auto" }));
    $("pauseMode").addEventListener("click", () => command("mode", { value: "paused" }, "已暂停自动调节。"));
    document.querySelectorAll("[data-scenario]").forEach((button) => button.addEventListener("click", () => command("scenario", { value: button.dataset.scenario })));
    document.querySelectorAll("[data-feedback]").forEach((button) => button.addEventListener("click", async () => {
      if (await command("feedback", { value: button.dataset.feedback }, "反馈已加入过程记录。")) {
        button.classList.add("feedback-flash"); setTimeout(() => button.classList.remove("feedback-flash"), 1000);
      }
    }));
    $("recordStart").addEventListener("click", () => command("record_start", { participant: $("participant").value.trim() }, "实验记录已开始，数据来源会一同保存。"));
    $("recordStop").addEventListener("click", async () => { if (await command("record_stop", {}, "记录已保存，可以回放或下载。")) await refreshSessions(); });
    $("refreshSessions").addEventListener("click", refreshSessions);
    $("refreshPorts").addEventListener("click", refreshPorts);
    $("connectSerial").addEventListener("click", connectSerial);
    $("unloadedCheck").addEventListener("change", () => { if (latest) updateEnabled(latest); });
    $("captureZero").addEventListener("click", async () => {
      if (!$("unloadedCheck").checked) return;
      if (await command("zero", {}, "已在电脑端记录空载背景；此操作未向固件发送命令。")) $("unloadedCheck").checked = false;
      if (latest) updateEnabled(latest);
    });
    $("configForm").addEventListener("submit", async (event) => {
      event.preventDefault();
      const values = {};
      for (const input of document.querySelectorAll("#configForm input")) values[input.name] = Number(input.value);
      if (Object.values(values).some((value) => !finite(value))) { notify("参数必须为有效数字。", true); return; }
      if (await command("config", { values }, "参数已更新，动作已暂停；检查后可重新启用自动。")) configLoaded = false;
    });
    window.addEventListener("resize", () => { drawChart(); matrixSignature = ""; if (latest) drawMatrix(latest.matrix); });
  }

  async function poll() {
    if (requestRunning) return;
    requestRunning = true;
    try {
      render(await fetchJson("/api/state"));
      if (Date.now() - lastSessionPoll > 7000) { lastSessionPoll = Date.now(); refreshSessions(); }
    } catch (error) {
      $("serverDot").className = "status-dot offline";
      setText("serverLabel", "本地服务未连接");
      setText("connectionError", "暂时无法连接本地服务。请确认启动程序仍在运行；页面恢复连接后会重新显示状态。");
      show("connectionError", true);
    } finally { requestRunning = false; }
  }

  createReadouts();
  connectEvents();
  updateEnabled({ source: {}, controller: {}, motor: {}, recording: {} });
  drawChart();
  poll();
  setInterval(poll, 200);
})();
