"""Local lumbar support demo. Physical actuator integration is intentionally absent."""

__version__ = "0.1.0"
