"""Read-only decoding and spatial mapping for the supplied ViTac firmware.

The source firmware sends compressed 8-bit ADC readings, not calibrated force.
Its ``diff`` and summary statistics are retained as evidence but never used to
construct the control input. The computer needs an explicitly captured empty
baseline AND a confirmed physical mapping before exposing eight zone values.
No serial write, motor command or personal comfort reference is implemented here.
"""
from __future__ import annotations

from collections import deque
from copy import deepcopy
import json
import math
from typing import Any


POINTS = 16 * 16
ZONES = 8
BASELINE_FRAMES = 16
MAX_LINE_BYTES = 16_384


def _integer(value: Any, label: str, low: int, high: int) -> int:
    # bool subclasses int in Python; a JSON true is never an ADC measurement.
    if type(value) is not int or not low <= value <= high:
        raise ValueError(f"{label} 必须是 {low}—{high} 范围内的整数")
    return value


def _vector(value: Any, label: str) -> list[int]:
    if not isinstance(value, list) or len(value) != POINTS:
        raise ValueError(f"{label} 必须包含完整的 256 个矩阵读数")
    return [_integer(item, f"{label}[{index}]", 0, 255)
            for index, item in enumerate(value)]


def _pairs(items: list[tuple[str, Any]]) -> dict:
    result: dict[str, Any] = {}
    for key, value in items:
        if key in result:
            raise ValueError(f"JSON 出现重复字段：{key}")
        result[key] = value
    return result


def _reject_constant(value: str) -> None:
    raise ValueError(f"JSON 不接受非有限数值：{value}")


def _finite_float(value: str) -> float:
    parsed = float(value)
    if not math.isfinite(parsed):
        raise ValueError("JSON 数值超出有限范围")
    return parsed


def matrix_stats(values: list[int] | list[float]) -> dict:
    """Summarize response units; no claimed force or verified contact label.

    A zero frame has no peak location. The number of nonzero cells can be 256.
    ``nz`` uses strictly > 0 and is not a noise-tested occupancy classifier.
    """
    if len(values) != POINTS:
        raise ValueError("统计必须使用完整的 256 点矩阵")
    peak = max(values, default=0)
    location = values.index(peak) if peak > 0 else -1
    return {
        "peak": peak,
        "pr": location // 16 if location >= 0 else -1,
        "pc": location % 16 if location >= 0 else -1,
        "nz": sum(value > 0 for value in values),
        "sum": sum(values),
        "units": "relative_signal",
    }


def decode_vitac_line(line: bytes | str) -> dict | None:
    """Decode one firmware JSON line, or ignore a blank/``#`` diagnostic line.

    This decoder is stateless. The service owns stream framing, freshness,
    sequence wrap/reboot handling, and exact raw-byte logging. It accepts the
    original 16-bit sequence and 32-bit millis() ranges without interpreting a
    wrap as a new independent hardware sample. Unknown well-formed fields are
    retained in ``original`` for forward-compatible diagnostics.
    """
    if isinstance(line, bytes):
        if len(line) > MAX_LINE_BYTES:
            raise ValueError("串口单行超过 16384 字节，已拒绝解析")
        try:
            text = line.decode("utf-8", errors="strict")
        except UnicodeDecodeError as exc:
            raise ValueError("串口行不是有效 UTF-8，请核对波特率和输出模式") from exc
    elif isinstance(line, str):
        try:
            size = len(line.encode("utf-8", errors="strict"))
        except UnicodeEncodeError as exc:
            raise ValueError("串口行包含无效 Unicode 字符") from exc
        if size > MAX_LINE_BYTES:
            raise ValueError("串口单行超过 16384 字节，已拒绝解析")
        text = line
    else:
        raise ValueError("串口输入必须是字节或文本")

    text = text.strip()
    if not text or text.startswith("#"):
        return None
    try:
        value = json.loads(text, object_pairs_hook=_pairs,
                           parse_constant=_reject_constant,
                           parse_float=_finite_float)
    except json.JSONDecodeError as exc:
        raise ValueError("数据不是完整 JSON 对象，请使用 JSON 输出模式") from exc
    except ValueError as exc:
        raise ValueError(f"JSON 字段或数值无效：{exc}") from exc
    except (RecursionError, OverflowError) as exc:
        raise ValueError("JSON 结构或数值超出允许范围") from exc
    if not isinstance(value, dict):
        raise ValueError("每一帧必须是一个 JSON 对象")
    for key in ("seq", "t", "base", "diff"):
        if key not in value:
            raise ValueError(f"JSON 帧缺少必填字段：{key}")

    seq = _integer(value["seq"], "seq", 0, 65_535)
    device_ms = _integer(value["t"], "t", 0, 4_294_967_295)
    baseline_flag = bool(_integer(value["base"], "base", 0, 1))
    firmware_diff = _vector(value["diff"], "diff")
    raw = None if value.get("raw") is None else _vector(value["raw"], "raw")

    # Validate types if present, but do not treat firmware summaries as truth.
    for key, low, high in (("peak", 0, 255), ("pr", -1, 15), ("pc", -1, 15),
                           ("nz", 0, 256), ("sum", 0, 65_535)):
        if key in value:
            _integer(value[key], key, low, high)
    return {
        "seq": seq,
        "device_ms": device_ms,
        "raw": raw,
        "firmware_diff": firmware_diff,
        "baseline_flag": baseline_flag,
        "original": value,
        "firmware_stats_recomputed": matrix_stats(firmware_diff),
    }


def empty_mapping() -> dict:
    """An explicit unconfirmed template; no invented physical coordinates."""
    return {
        "version": 1,
        "confirmed": False,
        "zones": [{"id": zone_id, "indices": [], "polarity": 1}
                  for zone_id in range(1, ZONES + 1)],
    }


def validate_mapping(mapping: dict | None) -> dict:
    if mapping is None:
        return empty_mapping()
    if not isinstance(mapping, dict):
        raise ValueError("位置映射必须是 JSON 对象")
    _integer(mapping.get("version", 1), "映射 version", 1, 1)
    confirmed = mapping.get("confirmed", False)
    if type(confirmed) is not bool:
        raise ValueError("映射 confirmed 必须是 true 或 false")
    entries = mapping.get("zones", [])
    if not isinstance(entries, list) or len(entries) > ZONES:
        raise ValueError("映射 zones 必须是最多包含八个区域的数组")

    supplied: dict[int, dict] = {}
    assigned: dict[int, int] = {}
    for entry in entries:
        if not isinstance(entry, dict):
            raise ValueError("每个映射区域必须是对象")
        zone_id = _integer(entry.get("id"), "区域 id", 1, ZONES)
        if zone_id in supplied:
            raise ValueError(f"区域 {zone_id} 被重复定义")
        indices = entry.get("indices", [])
        if not isinstance(indices, list):
            raise ValueError(f"区域 {zone_id} 的 indices 必须是数组")
        checked = [_integer(index, f"区域 {zone_id} 的索引", 0, POINTS - 1)
                   for index in indices]
        polarity = entry.get("polarity", 1)
        if type(polarity) is not int or polarity not in (-1, 1):
            raise ValueError(f"区域 {zone_id} 的 polarity 必须是 1 或 -1")
        for index in checked:
            if index in assigned:
                raise ValueError(f"矩阵索引 {index} 被重复分配到区域 {assigned[index]} 和 {zone_id}")
            assigned[index] = zone_id
        supplied[zone_id] = {"id": zone_id, "indices": checked,
                             "polarity": polarity}

    return {
        "version": 1,
        "confirmed": confirmed,
        "zones": [supplied.get(zone_id, {"id": zone_id, "indices": [], "polarity": 1})
                  for zone_id in range(1, ZONES + 1)],
    }


class MatrixProcessor:
    """Turn confirmed matrix regions into eight relative response means.

    ``capture_zero`` is an explicit empty-sensor operation only. It cannot
    determine whether a person is present; the UI/operator must ensure an empty
    surface, and the service must enforce a fresh recent stream. Calling it
    never captures or modifies a personal comfort target.

    ``matrix.diff`` always means positive raw-minus-computer-baseline before
    regional polarity. Each zone separately applies its confirmed polarity.
    This keeps a raw diagnostic heatmap distinct from mapped control inputs.
    """

    def __init__(self, mapping: dict | None = None):
        self.mapping = validate_mapping(mapping)
        self._raw_history: deque[list[int]] = deque(maxlen=BASELINE_FRAMES)
        self._baseline: list[float] | None = None
        self._last_raw: list[int] | None = None

    @property
    def mapping_ready(self) -> bool:
        return self.mapping["confirmed"] and all(zone["indices"] for zone in self.mapping["zones"])

    @property
    def baseline_ready(self) -> bool:
        return self._baseline is not None

    @property
    def baseline(self) -> list[float] | None:
        return None if self._baseline is None else self._baseline.copy()

    def reset(self) -> None:
        """Clear device-specific measurements while retaining configured mapping."""
        self._raw_history.clear()
        self._baseline = None
        self._last_raw = None

    def capture_zero(self) -> dict:
        if len(self._raw_history) < BASELINE_FRAMES or self._last_raw is None:
            raise ValueError("空载归零需要最近连续 16 帧 raw 读数；请保留 raw 输出并等待数据")
        # Python's integer sum has no uint8 overflow, including sixteen 255s.
        self._baseline = [sum(frame[index] for frame in self._raw_history) / BASELINE_FRAMES
                          for index in range(POINTS)]
        return {
            "baseline": self._baseline.copy(),
            "frames": BASELINE_FRAMES,
            "kind": "empty_sensor_baseline",
            "units": "compressed_adc8",
            "mapping": deepcopy(self.mapping),
            "note": "电脑端空载背景；需由操作者确认无人接触，不是个人舒适参考或力值标定。",
        }

    def consume(self, frame: dict) -> dict:
        if not isinstance(frame, dict):
            raise ValueError("矩阵输入必须是已解析的帧对象")
        raw_value = frame.get("raw")
        raw = None if raw_value is None else _vector(raw_value, "raw")
        firmware_diff = frame.get("firmware_diff")
        if firmware_diff is not None:
            firmware_diff = _vector(firmware_diff, "firmware_diff")

        warnings: list[str] = []
        values: list[float | None] = [None] * ZONES
        diff: list[float] | None = None
        if raw is None:
            # A missing-raw interval invalidates the candidate baseline window.
            self._raw_history.clear()
            self._last_raw = None
            warnings.append("当前帧缺少 raw，无法计算电脑端差值；请保留固件 JSON 的 raw 输出。")
        else:
            self._last_raw = raw.copy()
            self._raw_history.append(raw.copy())
            if self._baseline is not None:
                diff = [max(float(value) - zero, 0.0)
                        for value, zero in zip(raw, self._baseline)]
                if self.mapping_ready:
                    for zone in self.mapping["zones"]:
                        values[zone["id"] - 1] = sum(
                            max((raw[index] - self._baseline[index]) * zone["polarity"], 0.0)
                            for index in zone["indices"]
                        ) / len(zone["indices"])

        if not self.baseline_ready:
            warnings.append("尚未采集电脑端空载背景；请在无人接触时执行空载归零。")
        if not self.mapping_ready:
            warnings.append("八个实物位置尚未完成确认映射，区域读数暂为空。")
        return {
            "values": values,
            "matrix": {
                "raw": raw,
                "diff": diff,
                "firmware_diff": firmware_diff,
                "baseline_ready": self.baseline_ready,
                "mapping_ready": self.mapping_ready,
                "baseline_candidate_frames": len(self._raw_history),
                "diff_definition": "max(raw - computer_empty_baseline, 0); before zone polarity",
                "stats": matrix_stats(diff) if diff is not None else None,
            },
            "warnings": warnings,
        }
