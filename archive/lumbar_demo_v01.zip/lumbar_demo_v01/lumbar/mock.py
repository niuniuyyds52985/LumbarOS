"""A deliberately simple synthetic contact scene, not a validated body model."""
from __future__ import annotations

import math
import random


SCENARIOS = {
    "settled": "自然坐稳",
    "forward": "小幅前移",
    "back": "重新靠回",
    "sway": "轻微左右移动",
    "leave": "离座",
    "stale": "模拟数据中断",
    "invalid": "模拟腰部测点失效",
}


class SimulatedDevice:
    """Input and actuator share one state only in this synthetic adapter."""

    def __init__(self):
        self.random = random.Random(19)
        self.position = 0.42
        self.offset = 0.0
        self.scenario = "settled"
        self.seq = 0
        self.elapsed = 0.0
        self.action = "stop"
        self.speed = 0.0

    def set_scenario(self, scenario):
        if scenario not in SCENARIOS:
            raise ValueError("未知模拟场景")
        self.scenario = scenario

    def apply(self, action, speed):
        self.action = action if action in ("extend", "retract", "hold", "stop") else "stop"
        self.speed = max(0.0, min(0.35, float(speed))) if action in ("extend", "retract") else 0.0

    def step(self, dt):
        dt = max(0.0, min(float(dt), 0.1))
        self.elapsed += dt
        sign = 1 if self.action == "extend" else -1 if self.action == "retract" else 0
        # Arbitrary normalized simulation dynamics, not an actuator specification.
        self.position = max(0.04, min(0.88, self.position + sign * self.speed * 0.50 * dt))
        target = {"forward": 0.14, "back": -0.08, "leave": 0.7}.get(self.scenario, 0.0)
        self.offset += (target - self.offset) * min(1.0, 3.0 * dt)
        if self.scenario == "stale":
            return None
        self.seq += 1
        if self.scenario == "leave":
            zones = [0.0] * 8
        else:
            compression = max(0.0, 1.0 + 4.0 * (self.position - 0.42 - self.offset))
            sway = 0.13 * math.sin(self.elapsed * 1.4) if self.scenario == "sway" else 0.0
            shift = self.offset * 90.0
            zones = [28 + shift, 30 + shift, 53 - shift, 55 - shift,
                     30 * compression * (1 + sway), 35 * compression,
                     31 * compression * (1 - sway), max(0.0, 19 - self.offset * 110)]
            zones = [round(max(0.0, x + self.random.uniform(-0.25, 0.25)), 3) for x in zones]
        if self.scenario == "invalid":
            zones[5] = None
        return {"seq": self.seq, "device_ms": int(self.elapsed * 1000), "values": zones,
                "valid": self.scenario != "invalid", "matrix": None, "origin": "synthetic"}

    def motor_state(self):
        return {"can_execute": True, "applied_action": self.action,
                "position_fraction": round(self.position, 4), "position_origin": "simulated"}
