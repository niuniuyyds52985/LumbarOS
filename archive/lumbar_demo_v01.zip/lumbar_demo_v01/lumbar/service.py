"""Application service. Real serial is read-only; only the mock adapter moves."""
from __future__ import annotations

import base64
from collections import deque
from copy import deepcopy
from datetime import datetime, timezone
import io
import json
import math
from pathlib import Path
import re
import threading
import time
import uuid
import zipfile

from .controller import SupportController
from .actuator import ActuatorAdapter, UnconnectedActuator
from .input import MatrixProcessor, decode_vitac_line
from .mock import SCENARIOS, SimulatedDevice


ZONE_LABELS = ["座面前部 1", "座面前部 2", "座面后部 3", "座面后部 4",
               "活动腰托 5", "活动腰托 6", "活动腰托 7", "上部靠背 8"]
VALID_SESSION = re.compile(r"^S_[0-9A-Za-z_-]{1,80}$")


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def dumps(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


class SerialInput:
    """Nonblocking byte intake. There is intentionally no write method."""

    def __init__(self, port, baud):
        try:
            import serial
        except ImportError as exc:
            raise ValueError("串口模式需要可选依赖：python -m pip install -r requirements-serial.txt") from exc
        if not isinstance(port, str) or not port.strip() or len(port) > 255:
            raise ValueError("请填写串口名称，例如 COM3 或 /dev/ttyUSB0")
        if type(baud) is not int or baud not in (115200, 230400, 460800, 921600, 1000000, 2000000):
            raise ValueError("请选择支持的串口波特率，上传的固件默认 2000000")
        self.connection = serial.Serial(port=None, baudrate=baud, timeout=0)
        self.connection.dtr = False
        self.connection.rts = False
        self.connection.port = port
        self.connection.open()
        self.port, self.baud = port, baud
        self.pending = bytearray()
        self.discarding = False

    def poll(self):
        chunk = self.connection.read(min(65536, self.connection.in_waiting))
        lines, errors = [], []
        if not chunk:
            return lines, [], errors
        data = chunk
        if self.discarding:
            _, delimiter, data = data.partition(b"\n")
            if not delimiter:
                return lines, [chunk], errors
            self.discarding = False
        self.pending.extend(data)
        while b"\n" in self.pending:
            line, _, rest = self.pending.partition(b"\n")
            self.pending = bytearray(rest)
            if len(line) > 16384:
                errors.append("串口行超过 16 KiB，已保留原始字节并跳过解析")
            else:
                lines.append(bytes(line))
        if len(self.pending) > 16384:
            self.pending.clear()
            self.discarding = True
            errors.append("串口连续数据缺少换行，跳过直到下一个完整行边界")
        return lines, [chunk], errors

    def close(self):
        self.connection.close()


class Recorder:
    def __init__(self, root, origin, participant, config, mapping, *, calibration=None, clock=time.monotonic):
        self.id = "S_" + datetime.now().strftime("%Y%m%d_%H%M%S_") + uuid.uuid4().hex[:6]
        self.path = root / self.id
        self.path.mkdir(parents=True, exist_ok=False)
        self.clock = clock
        self.started = self.clock()
        self.frames = 0
        self.handles = {name: (self.path / (name + ".jsonl")).open("w", encoding="utf-8")
                        for name in ("frames", "events", "raw_wire")}
        self.metadata = {"schema_version": "lumbar-demo/0.1", "id": self.id,
                         "origin": origin, "participant": participant,
                         "created_at": utc_now(), "status": "recording", "frames": 0,
                         "measured_units": "relative_electrical_response",
                         "physical_actuator_commands_sent": False,
                         "notes": "synthetic 仅为仿真；serial_stream 为接收的电信号，未经力值标定。人工反馈不是姿态真值。"}
        write_json(self.path / "session.json", self.metadata)
        write_json(self.path / "controller_config.json", config)
        write_json(self.path / "hardware_mapping.json", mapping)
        write_json(self.path / "calibration.json", calibration or {})

    def append(self, name, value):
        self.handles[name].write(dumps(value) + "\n")
        self.handles[name].flush()

    def frame(self, state):
        self.frames += 1
        snapshot = deepcopy(state)
        snapshot.pop("events", None)
        snapshot.pop("recording", None)
        self.append("frames", {"captured_at": utc_now(), "elapsed_s": round(self.clock() - self.started, 6),
                               "data_origin": self.metadata["origin"], "snapshot": snapshot})

    def close(self):
        self.metadata.update(status="complete", frames=self.frames,
                             ended_at=utc_now(), duration_s=round(self.clock() - self.started, 3))
        write_json(self.path / "session.json", self.metadata)
        for handle in self.handles.values():
            handle.close()


class DemoService:
    def __init__(self, root, *, clock=time.monotonic):
        self.root = Path(root)
        self.clock = clock
        self.session_root = self.root / "sessions"
        self.session_root.mkdir(exist_ok=True)
        self.mapping = json.loads((self.root / "config" / "hardware.json").read_text(encoding="utf-8"))
        self.processor = MatrixProcessor(self.mapping)
        self.controller = SupportController()
        self.lock = threading.RLock()
        self.stopping = threading.Event()
        self.worker = None
        self.events = deque(maxlen=80)
        self.source_kind = "mock"
        self.source_detail = "模拟接触模型；所有数值与动作均为合成示例"
        self.connected = True
        self.device = SimulatedDevice()
        self.actuator: ActuatorAdapter = self.device
        self.serial = None
        self.recorder = None
        self.last_recording = None
        self.matrix = None
        self.values = [None] * 8
        self.seq = None
        self.device_ms = None
        self.frame_times = deque(maxlen=101)
        self.last_frame_at = None
        self.frames = 0
        self.invalid_frames = 0
        self.duplicate_frames = 0
        self.last_device_key = None
        self.last_step_at = self.clock()
        self.last_control_state = None
        self.message = "先调节到合适支撑，再点击“记住当前支撑”。"
        self.replay_records = []
        self.replay_index = 0
        self.replay_events = []
        self.replay_event_index = 0
        self.replay_started = 0.0
        self.replay_offset = 0.0
        self.replay_id = None
        self.replay_snapshot = None
        self._event("source", "已启动模拟设备；不会发送真实电机指令")

    def start(self):
        self.worker = threading.Thread(target=self._run, name="lumbar-demo-loop", daemon=True)
        self.worker.start()

    def close(self):
        self.stopping.set()
        if self.worker:
            self.worker.join(timeout=2)
        with self.lock:
            self.actuator.apply("stop", 0)
            if self.serial:
                self.serial.close()
                self.serial = None
            if self.recorder:
                self.recorder.close()
                self.recorder = None

    def _event(self, kind, label, **extra):
        event = {"time": utc_now(), "kind": kind, "label": label, **extra}
        self.events.append(event)
        if self.recorder:
            self.recorder.append("events", {**event, "elapsed_s": round(self.clock() - self.recorder.started, 6)})

    def _run(self):
        while not self.stopping.is_set():
            try:
                with self.lock:
                    self.step(self.clock())
            except Exception as exc:
                with self.lock:
                    self.connected = False
                    self.controller.set_mode("paused", self.clock())
                    self.actuator.apply("stop", 0)
                    self.message = "数据处理已暂停：" + str(exc)
                    if not self.events or self.events[-1]["label"] != self.message:
                        self._event("error", self.message)
            self.stopping.wait(0.05)

    def _accept(self, values, now, seq, device_ms, matrix, valid=True):
        self.values = list(values)
        self.seq, self.device_ms = seq, device_ms
        self.matrix = matrix
        self.frames += 1
        self.last_frame_at = now
        self.frame_times.append(now)
        self.controller.observe(self.values, now, valid=valid)

    def step(self, now):
        dt = max(0.0, min(now - self.last_step_at, 0.1))
        self.last_step_at = now
        fresh = False
        if self.source_kind == "mock":
            watchdog = self.controller.tick(now)
            self.actuator.apply(watchdog["action"], watchdog["speed"])
            frame = self.device.step(dt)
            if frame is not None:
                self._accept(frame["values"], now, frame["seq"], frame["device_ms"], None, frame["valid"])
                fresh = True
        elif self.source_kind == "serial" and self.serial:
            try:
                lines, chunks, errors = self.serial.poll()
            except Exception as exc:
                self.connected = False
                self.serial.close()
                self.serial = None
                self.controller.set_mode("paused", now)
                self.message = "串口连接已中断：" + str(exc)
                self._event("error", self.message)
                lines, chunks, errors = [], [], []
            for chunk in chunks:
                if self.recorder:
                    self.recorder.append("raw_wire", {"received_at": utc_now(),
                        "elapsed_s": round(now - self.recorder.started, 6),
                        "encoding": "base64", "bytes": base64.b64encode(chunk).decode("ascii")})
            for error in errors:
                self.invalid_frames += 1
                self._event("input_error", error)
            for line in lines:
                try:
                    frame = decode_vitac_line(line)
                    if frame is None:
                        if line.strip().startswith(b"#"):
                            self.message = line.decode("utf-8", errors="replace")[:300]
                        continue
                    key = (frame["seq"], frame["device_ms"])
                    if key == self.last_device_key:
                        self.duplicate_frames += 1
                        continue
                    if self.last_device_key and frame["device_ms"] < self.last_device_key[1]:
                        wraps = self.last_device_key[1] > 4294900000 and frame["device_ms"] < 100000
                        if not wraps:
                            self.processor.reset()
                            self.controller.reset(now)
                            self._event("device_restart", "设备时间回退：已清除电脑基线和个人参考，请重新确认空载与映射")
                    self.last_device_key = key
                    converted = self.processor.consume(frame)
                    self._accept(converted["values"], now, frame["seq"], frame["device_ms"],
                                 converted["matrix"], all(v is not None for v in converted["values"]))
                    fresh = True
                    # Every accepted wire frame is retained, including multiple
                    # frames arriving in one USB batch. Never collapse to the last.
                    if self.recorder:
                        self.recorder.frame(self._state(now))
                except ValueError as exc:
                    self.invalid_frames += 1
                    self._event("input_error", str(exc))
        elif self.source_kind == "replay":
            self._advance_replay(now)
            return

        control = self.controller.tick(now)
        self.actuator.apply(control["action"], control["speed"])
        current = (control["state"], control["action"])
        if current != self.last_control_state:
            self.last_control_state = current
            self._event("control", control["state_label"] + " · " + control["reason"])
        if fresh and self.recorder and self.source_kind == "mock":
            self.recorder.frame(self._state(now))

    def _state(self, now):
        rate = ((len(self.frame_times) - 1) / (self.frame_times[-1] - self.frame_times[0])
                if len(self.frame_times) > 1 and self.frame_times[-1] > self.frame_times[0] else 0.0)
        active = self.recorder
        state = {"version": "0.1.0", "source": {
            "kind": self.source_kind, "label": {"mock": "模拟设备", "serial": "真实串口 · 只读", "replay": "历史回放"}[self.source_kind],
            "connected": self.connected, "read_only": self.source_kind != "mock", "detail": self.source_detail},
            "zones": [{"id": i + 1, "label": ZONE_LABELS[i], "value": value, "valid": value is not None}
                      for i, value in enumerate(self.values)],
            "matrix": deepcopy(self.matrix), "controller": self.controller.snapshot(),
            "motor": self.actuator.motor_state(),
            "recording": {"active": bool(active), "session_id": active.id if active else self.last_recording,
                "frame_count": active.frames if active else 0,
                "elapsed_s": round(now - active.started, 2) if active else 0},
            "stats": {"frames": self.frames, "invalid_frames": self.invalid_frames,
                      "duplicate_frames": self.duplicate_frames, "rate_hz": round(rate, 2),
                      "frame_age_s": round(now - self.last_frame_at, 3) if self.last_frame_at is not None else None,
                      "seq": self.seq, "device_ms": self.device_ms},
            "events": (deepcopy(self.replay_events[max(0, self.replay_event_index - 40):self.replay_event_index])
                       if self.source_kind == "replay" else list(self.events)[-40:]),
            "mock": {"scenario": self.device.scenario},
            "replay": {"session_id": self.replay_id, "index": self.replay_index,
                       "count": len(self.replay_records), "ended": bool(self.replay_records)
                       and self.replay_index >= len(self.replay_records)
                       and self.replay_event_index >= len(self.replay_events)},
            "message": self.message}
        if self.source_kind == "replay" and self.replay_snapshot:
            original = self.replay_snapshot
            for key in ("zones", "matrix", "controller", "stats", "mock"):
                if key in original:
                    state[key] = deepcopy(original[key])
            state["motor"] = {"can_execute": False, "applied_action": "stop", "position_fraction": None,
                              "position_origin": "unknown", "recorded": deepcopy(original.get("motor"))}
            state["source"]["original_source"] = deepcopy(original.get("source"))
            state["message"] = "回放只展示原记录。图中的控制状态是历史建议，不会执行动作。"
        return state

    def state(self):
        with self.lock:
            return self._state(self.clock())

    def sessions(self):
        result = []
        for path in sorted(self.session_root.glob("S_*/session.json"), reverse=True):
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                result.append({"id": path.parent.name, "origin": data.get("origin"),
                               "frames": data.get("frames", 0), "created_at": data.get("created_at"),
                               "status": data.get("status")})
            except (OSError, ValueError):
                continue
        return {"sessions": result}

    def _session_path(self, session_id):
        if not isinstance(session_id, str) or not VALID_SESSION.fullmatch(session_id):
            raise ValueError("无效的记录编号")
        path = self.session_root / session_id
        if not path.is_dir():
            raise ValueError("找不到这段记录")
        if self.recorder and self.recorder.id == session_id:
            raise ValueError("请先结束记录，再下载或回放")
        return path

    def download(self, session_id):
        with self.lock:
            path = self._session_path(session_id)
            data = io.BytesIO()
            with zipfile.ZipFile(data, "w", zipfile.ZIP_DEFLATED) as archive:
                for item in sorted(path.iterdir()):
                    if item.is_file() and item.suffix in (".json", ".jsonl"):
                        archive.write(item, arcname=path.name + "/" + item.name)
            return data.getvalue()

    def _advance_replay(self, now):
        if not self.replay_records:
            return
        target = now - self.replay_started + self.replay_offset
        while self.replay_index < len(self.replay_records):
            record = self.replay_records[self.replay_index]
            if float(record["elapsed_s"]) > target:
                break
            self.replay_snapshot = record["snapshot"]
            self.replay_index += 1
        # Use the recording's clock for both streams. Keep original feedback
        # fields and timestamps; live events never belong to the replay.
        while self.replay_event_index < len(self.replay_events):
            event = self.replay_events[self.replay_event_index]
            if float(event["elapsed_s"]) > target:
                break
            self.replay_event_index += 1

    def _switch_source(self, payload, now):
        if self.recorder:
            raise ValueError("请先结束当前记录，再切换数据源")
        kind = payload.get("value")
        if kind not in ("mock", "serial", "replay"):
            raise ValueError("未知数据源")
        records, replay_events, new_serial = [], [], None
        if kind == "replay":
            session_path = self._session_path(payload.get("session_id"))
            path = session_path / "frames.jsonl"
            if not path.exists() or path.stat().st_size > 50 * 1024 * 1024:
                raise ValueError("当前回放支持不超过 50 MiB 的分试次记录")
            previous = -1.0
            with path.open(encoding="utf-8") as handle:
                for line in handle:
                    record = json.loads(line)
                    elapsed = record.get("elapsed_s")
                    if type(elapsed) not in (float, int) or not math.isfinite(elapsed) or elapsed < previous:
                        raise ValueError("记录的时间顺序无效，不能回放")
                    if not isinstance(record.get("snapshot"), dict):
                        raise ValueError("记录缺少状态快照")
                    previous = elapsed
                    records.append(record)
            if not records:
                raise ValueError("这段记录没有可回放的数据帧")
            event_path = session_path / "events.jsonl"
            # Older recordings may have no event stream. Validate the whole
            # selected stream before changing the current source.
            if event_path.exists():
                if event_path.stat().st_size > 5 * 1024 * 1024:
                    raise ValueError("当前回放支持不超过 5 MiB 的事件记录")
                previous = 0.0
                with event_path.open(encoding="utf-8") as handle:
                    for line in handle:
                        event = json.loads(line)
                        if not isinstance(event, dict):
                            raise ValueError("记录的事件格式无效，不能回放")
                        elapsed = event.get("elapsed_s")
                        if type(elapsed) not in (float, int) or not math.isfinite(elapsed) or elapsed < previous:
                            raise ValueError("记录的事件时间顺序无效，不能回放")
                        previous = elapsed
                        replay_events.append(event)
        elif kind == "serial":
            if self.serial:
                self.serial.close()
                self.serial = None
                self.connected = False
            new_serial = SerialInput(payload.get("port"), payload.get("baud", 2000000))
        self.controller.reset(now)
        self.actuator.apply("stop", 0)
        if self.serial:
            self.serial.close()
        self.serial = new_serial
        self.source_kind = kind
        self.connected = True
        self.values = [None] * 8
        self.matrix = None
        self.frames = self.invalid_frames = self.duplicate_frames = 0
        self.seq = self.device_ms = None
        self.frame_times.clear()
        self.last_frame_at = self.last_device_key = None
        self.processor = MatrixProcessor(self.mapping)
        self.last_control_state = None
        self.replay_records = records
        self.replay_index = 0
        self.replay_events = replay_events
        self.replay_event_index = 0
        self.replay_started = now
        self.replay_offset = records[0]["elapsed_s"] if records else 0.0
        self.replay_id = payload.get("session_id") if kind == "replay" else None
        self.replay_snapshot = None
        if kind == "mock":
            self.device = SimulatedDevice()
            self.actuator = self.device
            self.source_detail = "模拟接触模型；所有数值与动作均为合成示例"
        elif kind == "serial":
            self.actuator = UnconnectedActuator()
            self.source_detail = f"{new_serial.port} · {new_serial.baud} baud · 仅接收数据，不发送电机指令"
        else:
            self.actuator = UnconnectedActuator()
            self.source_detail = "历史记录回放；保持原始来源，禁止动作执行"
            self._advance_replay(now)
        self.message = "数据源已切换，个人参考已清除。"
        self._event("source", self.source_detail)

    def action(self, payload):
        if not isinstance(payload, dict):
            raise ValueError("请求必须是 JSON 对象")
        with self.lock:
            now = self.clock()
            name = payload.get("action")
            if self.source_kind == "replay" and name != "source":
                raise ValueError("回放模式仅供查看；请切回模拟或串口后操作")
            if name == "source":
                self._switch_source(payload, now)
            elif name == "mode":
                self.controller.set_mode(payload.get("value"), now)
                self._event("mode", "控制模式切换：" + str(payload.get("value")))
            elif name == "manual":
                if self.source_kind != "mock":
                    raise ValueError("真实电机接入口尚未实现，当前只允许在模拟设备上手动移动")
                self.controller.manual(payload.get("direction"), now, duration=0.2)
                self._event("manual", "模拟手动动作：" + str(payload.get("direction")))
            elif name == "calibrate":
                self.controller.capture_reference(now)
                self.message = "已记住当前支撑；参考不会随姿态自动改写。"
                self._event("reference", self.message, reference=self.controller.snapshot().get("reference"))
            elif name == "zero":
                if self.source_kind != "serial":
                    raise ValueError("空载归零用于真实阵列输入；模拟信号已使用合成零背景")
                if self.last_frame_at is None or now - self.last_frame_at > 0.4:
                    raise ValueError("数据已过期，请恢复串口读数后再采集空载背景")
                baseline = self.processor.capture_zero()
                self.controller.reset(now)
                self._event("zero", "已在电脑端采集空载背景；个人参考已清除", calibration=baseline)
                self.message = "请确认传感器刚才确实为空载。现在可坐下调节个人支撑。"
            elif name == "scenario":
                if self.source_kind != "mock":
                    raise ValueError("场景按钮只用于模拟数据")
                self.device.set_scenario(payload.get("value"))
                self._event("scenario", "模拟场景：" + SCENARIOS[self.device.scenario])
            elif name == "feedback":
                labels = {"too_strong": "有点顶", "good": "支撑合适", "too_weak": "有点空"}
                value = payload.get("value")
                if value not in labels:
                    raise ValueError("未知反馈")
                self._event("feedback", labels[value], value=value, label_type="user_report_not_posture_truth")
            elif name == "record_start":
                if self.recorder:
                    raise ValueError("当前已经在记录")
                participant = payload.get("participant", "")
                if not isinstance(participant, str) or len(participant) > 80:
                    raise ValueError("参与者编号请使用不超过 80 字的匿名编号")
                origin = "synthetic" if self.source_kind == "mock" else "serial_stream"
                self.recorder = Recorder(self.session_root, origin, participant,
                    self.controller.snapshot()["config"], self.mapping, clock=self.clock,
                    calibration={"computer_empty_baseline": self.processor.baseline,
                                 "personal_reference": self.controller.snapshot()["reference"],
                                 "units": "relative_electrical_response",
                                 "source": self.source_kind,
                                 "note": "记录开始时的快照；此后的归零与个人标定写入 events.jsonl。"})
                self._event("record", "开始记录；数据来源：" + origin)
            elif name == "record_stop":
                if not self.recorder:
                    raise ValueError("当前没有正在进行的记录")
                self._event("record", "结束记录")
                self.last_recording = self.recorder.id
                self.recorder.close()
                self.recorder = None
            elif name == "config":
                self.controller.update_config(payload.get("values", {}), now)
                self._event("config", "控制参数已更新，自动动作已暂停", config=self.controller.snapshot()["config"])
            else:
                raise ValueError("未知操作")
            command = self.controller.tick(now)
            self.actuator.apply(command["action"], command["speed"])
            return self._state(now)


def list_serial_ports():
    try:
        from serial.tools import list_ports
    except ImportError:
        return {"ports": [], "available": False}
    return {"ports": [{"device": p.device, "description": p.description} for p in list_ports.comports()],
            "available": True}
