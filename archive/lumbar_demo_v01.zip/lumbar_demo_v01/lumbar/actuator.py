"""The output seam: a shared plate has one extend/retract/stop command.

Implement this protocol after the real driver and device-side stop behaviour
are confirmed. A config flag alone never enables physical motion in v0.1.
"""
from __future__ import annotations

from typing import Protocol


class ActuatorAdapter(Protocol):
    def apply(self, action: str, speed: float) -> None:
        """Accept a bounded normalized request; this is not a force in N."""
        ...

    def motor_state(self) -> dict:
        """Report actual capability and observed position, if available."""
        ...


class UnconnectedActuator:
    """Explicit no-I/O adapter for real sensor input and historical replay."""

    def __init__(self):
        self.requested_action = "stop"
        self.requested_speed = 0.0

    def apply(self, action, speed):
        self.requested_action = action
        self.requested_speed = float(speed)

    def motor_state(self):
        return {"can_execute": False, "applied_action": "stop",
                "position_fraction": None, "position_origin": "unknown",
                "requested_action": self.requested_action,
                "requested_speed": self.requested_speed,
                "detail": "物理执行器未接入；以上请求仅供观察，未发送。"}
