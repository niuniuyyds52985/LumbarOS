"""Small reference controller for the lumbar-support software demo.

This module emits *requested* motion only. It never talks to a motor. Every
default below is a simulation tuning value in relative sensor units; none is a
validated force limit, a physical speed, or a prescription for human testing.
The service must independently prohibit actuator writes for serial and replay.
"""
from __future__ import annotations

from collections import deque
from copy import deepcopy
import math
from statistics import median


DEFAULT_CONFIG = {
    "lower_ratio": 0.88,
    "upper_ratio": 1.16,
    "advance_stop_ratio": 0.98,
    "return_stop_ratio": 1.06,
    "confirm_s": 0.30,
    "stale_s": 0.40,
    "max_speed": 0.35,
    "min_speed": 0.04,
    "gain": 0.80,
    "seat_min_signal": 5.0,
    "lumbar_min_signal": 1.0,
    "reference_min_signal": 3.0,
    "local_guard_ratio": 1.35,
    "local_return_ratio": 1.12,
    "overload_ratio": 1.80,
    "signal_ceiling": 255.0,
    "motion_timeout_s": 3.0,
    "calibration_window_s": 1.50,
    "calibration_spread_ratio": 0.12,
    "settle_s": 0.25,
    "manual_max_s": 0.35,
}

_BOUNDS = {
    "lower_ratio": (0.30, 0.99),
    "upper_ratio": (1.01, 1.80),
    "advance_stop_ratio": (0.50, 1.10),
    "return_stop_ratio": (0.90, 1.50),
    "confirm_s": (0.05, 2.00),
    "stale_s": (0.05, 2.00),
    "max_speed": (0.01, 0.50),
    "min_speed": (0.00, 0.20),
    "gain": (0.05, 3.00),
    "seat_min_signal": (0.10, 1000.0),
    "lumbar_min_signal": (0.05, 100.0),
    "reference_min_signal": (0.10, 200.0),
    "local_guard_ratio": (1.05, 2.00),
    "local_return_ratio": (1.00, 1.70),
    "overload_ratio": (1.20, 3.00),
    "signal_ceiling": (5.0, 10000.0),
    "motion_timeout_s": (0.30, 10.0),
    "calibration_window_s": (1.50, 5.00),
    "calibration_spread_ratio": (0.01, 0.40),
    "settle_s": (0.05, 1.00),
    "manual_max_s": (0.05, 0.50),
}

_LABELS = {
    "WAITING": "等待数据", "MANUAL": "手动调节", "PAUSED": "已暂停",
    "REFERENCE_READY": "参考已记录", "HOLD": "支撑保持",
    "CONFIRM_EXTEND": "确认接触减弱", "CONFIRM_RETRACT": "确认接触增强",
    "EXTEND": "建议前顶", "RETRACT": "建议回退",
    "MANUAL_EXTEND": "手动前顶", "MANUAL_RETRACT": "手动回退",
    "STALE": "数据中断", "INVALID": "数据不可用", "ABSENT": "座面无接触",
    "CONTACT_LOST": "腰部接触丢失", "OVERLOAD": "响应超过示例上限",
    "MOTION_TIMEOUT": "调整时间已到", "SETTLING": "等待动作稳定",
}


def _finite(value):
    return type(value) in (int, float) and math.isfinite(value)


def _validate_config(changes, current=None):
    if not isinstance(changes, dict):
        raise ValueError("参数必须是一个对象。")
    unknown = set(changes) - set(DEFAULT_CONFIG)
    if unknown:
        raise ValueError("未知参数：" + ", ".join(sorted(unknown)))
    cfg = dict(DEFAULT_CONFIG if current is None else current)
    for key, value in changes.items():
        lo, hi = _BOUNDS[key]
        if not _finite(value) or not lo <= value <= hi:
            raise ValueError(f"参数 {key} 需要在 {lo:g}—{hi:g} 之间。")
        cfg[key] = float(value)
    if not (cfg["lower_ratio"] < cfg["advance_stop_ratio"]
            <= cfg["return_stop_ratio"] < cfg["upper_ratio"]):
        raise ValueError("阈值应满足：前顶触发 < 前顶停止 ≤ 回退停止 < 回退触发。")
    if not (cfg["local_return_ratio"] < cfg["local_guard_ratio"]
            < cfg["overload_ratio"]):
        raise ValueError("单点停止阈值、单点回退阈值和示例上限需要依次增大。")
    if cfg["upper_ratio"] >= cfg["overload_ratio"]:
        raise ValueError("正常回退阈值必须低于独立的示例上限。")
    if cfg["min_speed"] > cfg["max_speed"]:
        raise ValueError("最小动作幅度不能高于最大动作幅度。")
    if cfg["lumbar_min_signal"] >= cfg["reference_min_signal"]:
        raise ValueError("记录参考的接触要求应高于接触丢失阈值。")
    if cfg["reference_min_signal"] >= cfg["signal_ceiling"]:
        raise ValueError("参考最低响应必须低于响应上限。")
    return cfg


class SupportController:
    """Eight-zone controller; zones 5/6/7 move with one common lumbar plate."""

    def __init__(self, config: dict | None = None):
        self.config = _validate_config(config or {})
        self.reset(0.0)

    def reset(self, now: float) -> dict:
        if not _finite(now) or now < 0:
            raise ValueError("需要非负、有限的单调时间。")
        self._now = float(now)
        self._last_frame_at = None
        self._zones = None
        self._history = deque(maxlen=4096)
        self.reference = None
        self.mode = "manual"
        self.state = "WAITING"
        self.reason = "等待八个区域的有效读数；当前没有动作。"
        self.action = "stop"
        self.speed = 0.0
        self._fault = None
        self._candidate = None
        self._candidate_since = None
        self._candidate_count = 0
        self._motion_started = None
        self._manual_until = None
        self._last_motion_at = None
        return self.snapshot()

    def _time(self, now):
        if not _finite(now) or now < self._now - 1e-9:
            raise ValueError("时间必须是递增的单调秒数。")
        self._now = float(now)
        return self._now

    def _set_action(self, action, speed=0.0):
        previous = self.action
        if action in ("extend", "retract"):
            if previous != action:
                self._motion_started = self._now
            self._last_motion_at = self._now
            self.speed = max(0.0, min(float(speed), self.config["max_speed"]))
        else:
            if previous in ("extend", "retract"):
                self._last_motion_at = self._now
            self.speed = 0.0
            self._motion_started = None
        self.action = action

    def _clear_candidate(self):
        self._candidate = None
        self._candidate_since = None
        self._candidate_count = 0

    def _trip(self, state, reason):
        self.mode = "paused"
        self.state = state
        self.reason = reason
        self._fault = state
        self._manual_until = None
        self._set_action("stop")
        self._clear_candidate()
        self._history.clear()

    def _fresh(self):
        return (self._last_frame_at is not None and self._zones is not None
                and self._now - self._last_frame_at <= self.config["stale_s"])

    def _occupied(self):
        return self._zones is not None and sum(self._zones[:4]) > self.config["seat_min_signal"]

    def _lumbar_contact(self):
        return self._zones is not None and max(self._zones[4:7]) > self.config["lumbar_min_signal"]

    def _ratios(self):
        if not self.reference or self._zones is None:
            return None, [], 0.0
        active = self.reference["active_lumbar"]
        reference = self.reference["zones"]
        # All three pads contribute to the common plate's relative response,
        # including a pad that had little contact when the reference was saved.
        # This is a ratio of sensor-signal sums, not a calibrated force ratio.
        denom = sum(reference[4:7])
        overall = sum(self._zones[4:7]) / denom if denom else None
        active_scale = median(reference[i] for i in active)
        # Retain each well-contacted pad's personal reference. For a low/zero
        # reference pad use the active pads' median, avoiding a zero denominator
        # while still including new local contact in the normal feedback guard.
        ratios = [self._zones[i] / (reference[i] if i in active else active_scale)
                  for i in range(4, 7)]
        return overall, ratios, max(ratios, default=0.0)

    def _overloaded(self):
        if self._zones is None:
            return False
        if max(self._zones[4:7]) >= self.config["signal_ceiling"]:
            return True
        _, ratios, peak = self._ratios()
        if ratios and peak >= self.config["overload_ratio"]:
            return True
        return False

    def _settled(self):
        return (self.action not in ("extend", "retract") and
                (self._last_motion_at is None or
                 self._now - self._last_motion_at >= self.config["settle_s"]))

    def _reference_window(self):
        if not self._fresh() or not self._occupied() or not self._lumbar_contact() or not self._settled():
            return None
        if len(self._history) < 10:
            return None
        samples = list(self._history)
        if samples[-1][0] - samples[0][0] + 1e-9 < self.config["calibration_window_s"]:
            return None
        center = [float(median(row[i] for _, row in samples)) for i in range(8)]
        active = [i for i in range(4, 7) if center[i] >= self.config["reference_min_signal"]]
        if not active or max(center[4:7]) >= self.config["signal_ceiling"]:
            return None
        for i in range(4, 7):
            readings = [row[i] for _, row in samples]
            spread = (max(readings) - min(readings)) / max(center[i], self.config["reference_min_signal"])
            if spread > self.config["calibration_spread_ratio"]:
                return None
        seat = [sum(row[:4]) for _, row in samples]
        if min(seat) <= self.config["seat_min_signal"]:
            return None
        return center, active

    def observe(self, zones: list[float | None], now: float, *, valid: bool = True) -> dict:
        now = self._time(now)
        previous_at = self._last_frame_at
        if (valid is not True or not isinstance(zones, (list, tuple)) or len(zones) != 8
                or any(not _finite(x) or x < 0 for x in zones)):
            self._zones = None
            self._trip("INVALID", "八区数据存在缺失或非法值；恢复数据后请手动重新启用。")
            return self.snapshot()
        if previous_at is not None and now - previous_at > self.config["stale_s"]:
            self._trip("STALE", "采样间隔过长，已停止调整；确认数据恢复后再启用。")
        self._zones = [float(x) for x in zones]
        self._last_frame_at = now

        if not self._occupied():
            self._trip("ABSENT", "座面接触不足，已停止追随；重新入座后请手动启用。")
            return self.snapshot()
        if self._overloaded():
            self._trip("OVERLOAD", "局部响应超过模拟配置上限，已暂停；停止动作不等于卸力。")
            return self.snapshot()
        if self.mode == "auto" and not self._lumbar_contact():
            self._trip("CONTACT_LOST", "腰部接触已丢失，停止继续前顶；请手动重新确认接触。")
            return self.snapshot()

        if self._settled() and self._lumbar_contact():
            # Retain one sample straddling the time-window boundary so that
            # a slightly irregular stream can reach the required duration.
            self._history.append((now, tuple(self._zones)))
            cutoff = now - self.config["calibration_window_s"]
            while len(self._history) > 1 and self._history[1][0] <= cutoff:
                self._history.popleft()
        else:
            self._history.clear()

        if self.mode == "auto":
            self._automatic()
        elif self._fault is None and self._manual_until is None:
            self.state = "MANUAL" if self.mode == "manual" else "PAUSED"
            self.reason = "可手动微调，稳定后记住当前支撑。" if self.mode == "manual" else "自动调节已暂停。"
            self._set_action("stop")
        return self.tick(now)

    def _automatic(self):
        if not self.reference:
            self._trip("INVALID", "个人支撑参考缺失，请先记住当前支撑。")
            return
        ratio, _, peak_ratio = self._ratios()
        cfg = self.config
        local_high = peak_ratio > cfg["local_guard_ratio"]

        if self.action == "extend":
            if local_high or ratio >= cfg["advance_stop_ratio"]:
                self._set_action("hold")
                self._clear_candidate()
                self.state = "SETTLING"
                self.reason = "前顶已停止，等待接触稳定。"
            else:
                self._set_action("extend", self._speed_for(max(0.0, 1.0 - ratio)))
                self.state = "EXTEND"
                self.reason = "接触偏弱，给出受限的缓慢前顶建议。"
            return
        if self.action == "retract":
            if ratio <= cfg["return_stop_ratio"] and peak_ratio <= cfg["local_return_ratio"]:
                self._set_action("hold")
                self._clear_candidate()
                self.state = "SETTLING"
                self.reason = "已回到参考范围内，停止回退并保留支撑。"
            else:
                error = max(ratio - 1.0, peak_ratio - cfg["local_return_ratio"], 0.0)
                self._set_action("retract", self._speed_for(error))
                self.state = "RETRACT"
                self.reason = "接触偏强，给出受限的缓慢回退建议。"
            return

        if not self._settled():
            self._clear_candidate()
            self._set_action("hold")
            self.state = "SETTLING"
            self.reason = "等待上一段动作后的接触稳定。"
            return
        candidate = "retract" if local_high or ratio > cfg["upper_ratio"] else (
            "extend" if ratio < cfg["lower_ratio"] else None)
        if candidate is None:
            self._clear_candidate()
            self._set_action("hold")
            self.state = "HOLD"
            self.reason = "接触在允许范围内，保持当前支撑。"
            return
        if candidate != self._candidate:
            self._candidate = candidate
            self._candidate_since = self._now
            self._candidate_count = 1
        else:
            self._candidate_count += 1
        if self._now - self._candidate_since + 1e-9 < cfg["confirm_s"] or self._candidate_count < 3:
            self._set_action("hold")
            self.state = "CONFIRM_RETRACT" if candidate == "retract" else "CONFIRM_EXTEND"
            self.reason = "确认连续变化，避免短暂波动触发机构。"
            return
        error = max(ratio - 1.0, peak_ratio - cfg["local_return_ratio"], 0.0) if candidate == "retract" else 1.0 - ratio
        self._set_action(candidate, self._speed_for(error))
        self._history.clear()
        self.state = "RETRACT" if candidate == "retract" else "EXTEND"
        self.reason = "局部接触偏强，优先回退。" if local_high else (
            "接触偏强，缓慢回退。" if candidate == "retract" else "接触偏弱，缓慢前顶。")

    def _speed_for(self, error):
        return min(self.config["max_speed"], max(self.config["min_speed"], self.config["gain"] * error))

    def tick(self, now: float) -> dict:
        self._time(now)
        if (self._last_frame_at is not None and
                self._now - self._last_frame_at > self.config["stale_s"]):
            if self._fault != "STALE":
                self._trip("STALE", "压力数据已超时，停止动作；数据恢复后需手动启用。")
            return self.snapshot()
        if self._manual_until is not None and self._now >= self._manual_until:
            self._manual_until = None
            self._set_action("stop")
            self.state = "MANUAL"
            self.reason = "本次手动小步已结束。"
        if (self._motion_started is not None and
                self._now - self._motion_started >= self.config["motion_timeout_s"]):
            self._trip("MOTION_TIMEOUT", "持续调整未达到停止条件，已暂停；请检查接触与机构响应。")
        return self.snapshot()

    def capture_reference(self, now: float) -> dict:
        self.tick(now)
        window = self._reference_window()
        if window is None:
            raise ValueError("请先入座并接触腰托，停止动作后保持至少 1.5 秒稳定，再记住支撑。")
        center, active = window
        self.reference = {"zones": center, "active_lumbar": active,
                          "captured_at": self._now, "units": "relative_signal",
                          "note": "用户确认的相对接触参考，不是经标定的力值。"}
        self.mode = "manual"
        self._fault = None
        self._manual_until = None
        self._set_action("stop")
        self._clear_candidate()
        self.state = "REFERENCE_READY"
        self.reason = "已记录当前支撑；可显式启用自动调节。"
        return self.snapshot()

    def set_mode(self, mode: str, now: float) -> dict:
        self.tick(now)
        if mode not in ("manual", "auto", "paused"):
            raise ValueError("模式只能是 manual、auto 或 paused。")
        if mode == "auto":
            if self.reference is None:
                raise ValueError("请先记住一个稳定、合适的个人支撑状态。")
            if not self._fresh() or not self._occupied() or not self._lumbar_contact():
                raise ValueError("需要新鲜、完整、在座且有腰部接触的数据，才能启用自动调节。")
            if self._overloaded():
                raise ValueError("当前局部响应超过示例上限，请先调整接触状态。")
        self.mode = mode
        self._fault = None
        self._manual_until = None
        self._clear_candidate()
        self._set_action("hold" if mode == "auto" else "stop")
        self.state = "HOLD" if mode == "auto" else ("MANUAL" if mode == "manual" else "PAUSED")
        self.reason = ("自动调节已启用，等待后续帧判断。" if mode == "auto" else
                       "手动模式，每次动作都有时间上限。" if mode == "manual" else "已暂停，当前无动作。")
        return self.snapshot()

    def manual(self, direction: str, now: float, duration: float = 0.20) -> dict:
        self.tick(now)
        if direction not in ("extend", "retract", "stop"):
            raise ValueError("手动方向只能是 extend、retract 或 stop。")
        if direction == "stop":
            self.mode = "manual"
            self._manual_until = None
            self._clear_candidate()
            self._set_action("stop")
            self.state = "MANUAL"
            self.reason = "手动停止。"
            return self.snapshot()
        if self.mode != "manual":
            raise ValueError("请先切换到手动模式，再进行小步调整。")
        if not self._fresh() or not self._occupied():
            raise ValueError("手动调节需要新鲜、完整的在座数据。")
        if self._overloaded():
            raise ValueError("当前响应超过示例上限，请先检查接触状态。")
        if not _finite(duration) or not 0 < duration <= self.config["manual_max_s"]:
            raise ValueError(f"单次手动动作需大于 0 且不超过 {self.config['manual_max_s']:g} 秒。")
        # Do not allow repeated UI commands to renew one unbounded pulse.
        if self._manual_until is not None and self._now < self._manual_until:
            raise ValueError("上一小步尚未结束，请稍候。")
        self._fault = None
        self._history.clear()
        self._manual_until = self._now + float(duration)
        self._set_action(direction, min(0.20, self.config["max_speed"]))
        self.state = "MANUAL_EXTEND" if direction == "extend" else "MANUAL_RETRACT"
        self.reason = "执行一次有时限的模拟小步。"
        return self.snapshot()

    def update_config(self, changes: dict, now: float) -> dict:
        cfg = _validate_config(changes, self.config)
        self._time(now)
        self.config = cfg
        self.mode = "paused"
        self._fault = None
        self._manual_until = None
        self._clear_candidate()
        self._set_action("stop")
        self._history.clear()
        self.state = "PAUSED"
        self.reason = "模拟参数已更新，个人参考保持不变；检查后再启用。"
        return self.snapshot()

    def snapshot(self) -> dict:
        ratio, _, peak_ratio = self._ratios()
        return {
            "mode": self.mode, "state": self.state,
            "state_label": _LABELS.get(self.state, self.state), "reason": self.reason,
            "action": self.action, "speed": self.speed,
            "support_ratio": ratio, "local_peak_ratio": peak_ratio if self.reference else None,
            "reference": deepcopy(self.reference),
            "reference_ready": self._reference_window() is not None,
            "band": {"lower": self.config["lower_ratio"], "upper": self.config["upper_ratio"],
                     "advance_stop": self.config["advance_stop_ratio"],
                     "return_stop": self.config["return_stop_ratio"]},
            "config": dict(self.config),
            "parameters_are_simulation_examples": True,
        }
