"""Behavioral tests with synthetic signals; not a physical controller validation."""
import unittest

from lumbar.controller import SupportController


BASE = [40.0, 40.0, 80.0, 80.0, 40.0, 40.0, 40.0, 15.0]


class ControllerTests(unittest.TestCase):
    def setUp(self):
        self.controller = SupportController()
        self.time = 0.0

    def feed(self, zones=BASE, seconds=0.05):
        count = max(1, round(seconds / 0.05))
        state = None
        for _ in range(count):
            self.time = round(self.time + 0.05, 8)
            state = self.controller.observe(list(zones), self.time)
        return state

    def calibrated(self):
        self.feed(seconds=1.65)
        self.controller.capture_reference(self.time)
        self.controller.set_mode("auto", self.time)
        return self.controller

    def test_auto_requires_explicit_stable_reference(self):
        self.feed(seconds=0.4)
        with self.assertRaises(ValueError):
            self.controller.capture_reference(self.time)
        with self.assertRaises(ValueError):
            self.controller.set_mode("auto", self.time)
        self.feed(seconds=1.3)
        state = self.controller.capture_reference(self.time)
        self.assertEqual(state["reference"]["zones"][4:7], [40, 40, 40])
        self.assertEqual(state["mode"], "manual")
        self.assertEqual(state["action"], "stop")

    def test_unstable_or_empty_reference_is_rejected(self):
        for i in range(36):
            zones = list(BASE)
            zones[5] = 32 if i % 2 else 49
            self.feed(zones)
        self.assertFalse(self.controller.snapshot()["reference_ready"])
        with self.assertRaises(ValueError):
            self.controller.capture_reference(self.time)
        self.feed([0] * 8, seconds=1.7)
        with self.assertRaises(ValueError):
            self.controller.capture_reference(self.time)

    def test_in_band_and_short_transient_do_not_move(self):
        self.calibrated()
        weak = BASE[:4] + [30, 30, 30] + BASE[7:]
        state = self.feed(weak, seconds=0.15)
        self.assertEqual(state["action"], "hold")
        state = self.feed(BASE, seconds=0.5)
        self.assertEqual(state["action"], "hold")
        self.assertEqual(state["state"], "HOLD")

    def test_retraction_uses_separate_stop_boundary(self):
        self.calibrated()
        strong = BASE[:4] + [52, 52, 52] + BASE[7:]
        state = self.feed(strong, seconds=0.4)
        self.assertEqual(state["action"], "retract")
        between = BASE[:4] + [45, 45, 45] + BASE[7:]
        state = self.feed(between)
        self.assertEqual(state["action"], "retract")
        recovered = BASE[:4] + [41.5, 41.5, 41.5] + BASE[7:]
        state = self.feed(recovered)
        self.assertEqual(state["action"], "hold")
        self.assertEqual(state["speed"], 0)

    def test_extension_stops_inside_band(self):
        self.calibrated()
        weak = BASE[:4] + [28, 28, 28] + BASE[7:]
        self.assertEqual(self.feed(weak, seconds=0.4)["action"], "extend")
        self.assertEqual(self.feed(BASE[:4] + [36, 36, 36] + BASE[7:])["action"], "extend")
        self.assertEqual(self.feed(BASE)["action"], "hold")

    def test_single_high_pad_overrides_low_average(self):
        self.calibrated()
        uneven = BASE[:4] + [58, 15, 15] + BASE[7:]
        state = self.feed(uneven, seconds=0.4)
        self.assertLess(state["support_ratio"], 0.88)
        self.assertEqual(state["action"], "retract")

    def test_new_contact_on_low_reference_pad_affects_common_feedback(self):
        for lumbar, expected_ratio in (([40, 20, 40], 1.25),
                                       ([10, 56, 10], 0.95)):
            with self.subTest(lumbar=lumbar):
                self.setUp()
                low_middle = BASE[:4] + [40, 0, 40] + BASE[7:]
                self.feed(low_middle, seconds=1.65)
                reference = self.controller.capture_reference(self.time)
                self.assertEqual(reference["reference"]["active_lumbar"], [4, 6])
                self.controller.set_mode("auto", self.time)
                state = self.feed(BASE[:4] + lumbar + BASE[7:], seconds=0.4)
                self.assertAlmostEqual(state["support_ratio"], expected_ratio)
                self.assertEqual(state["action"], "retract")
                self.assertEqual(state["mode"], "auto")
                self.assertLess(state["local_peak_ratio"], state["config"]["overload_ratio"])

    def test_overload_latches_and_does_not_self_resume(self):
        self.calibrated()
        state = self.feed(BASE[:4] + [80, 25, 25] + BASE[7:])
        self.assertEqual(state["state"], "OVERLOAD")
        self.assertEqual(state["mode"], "paused")
        self.assertEqual(self.feed(BASE, seconds=0.5)["action"], "stop")
        self.assertEqual(self.controller.snapshot()["mode"], "paused")
        self.controller.manual("stop", self.time)
        self.assertEqual(self.feed(BASE)["mode"], "manual")
        self.assertEqual(self.controller.snapshot()["action"], "stop")
        self.controller.set_mode("auto", self.time)
        self.assertEqual(self.feed(BASE)["mode"], "auto")

    def test_absence_and_contact_loss_stop_following(self):
        for zones, expected in (([0] * 8, "ABSENT"),
                                (BASE[:4] + [0, 0, 0] + BASE[7:], "CONTACT_LOST")):
            with self.subTest(expected=expected):
                self.setUp()
                self.calibrated()
                state = self.feed(zones)
                self.assertEqual(state["state"], expected)
                self.assertEqual(state["action"], "stop")
                self.assertEqual(self.feed(BASE, seconds=0.5)["mode"], "paused")

    def test_watchdog_stops_when_no_new_frame_arrives(self):
        self.calibrated()
        self.feed(BASE[:4] + [28, 28, 28] + BASE[7:], seconds=0.4)
        self.assertEqual(self.controller.snapshot()["action"], "extend")
        self.time += 0.41
        state = self.controller.tick(self.time)
        self.assertEqual(state["state"], "STALE")
        self.assertEqual(state["action"], "stop")
        self.assertEqual(self.feed(BASE, seconds=0.5)["mode"], "paused")

    def test_invalid_data_cannot_become_zero_pressure(self):
        for value in (None, float("nan"), float("inf"), -1, True):
            with self.subTest(value=value):
                self.setUp()
                self.calibrated()
                zones = list(BASE)
                zones[5] = value
                state = self.feed(zones)
                self.assertEqual(state["state"], "INVALID")
                self.assertEqual(state["action"], "stop")
                self.assertEqual(self.controller.tick(self.time)["state"], "INVALID")
                self.assertEqual(self.feed(BASE, seconds=0.1)["mode"], "paused")

    def test_persistent_low_response_cannot_chase_forever(self):
        self.calibrated()
        state = self.feed(BASE[:4] + [15, 15, 15] + BASE[7:], seconds=3.5)
        self.assertEqual(state["state"], "MOTION_TIMEOUT")
        self.assertEqual(state["action"], "stop")
        self.assertEqual(state["mode"], "paused")

    def test_manual_pulse_expires_without_another_sensor_frame(self):
        self.feed(seconds=0.3)
        state = self.controller.manual("extend", self.time)
        self.assertEqual(state["action"], "extend")
        self.time += 0.10
        with self.assertRaises(ValueError):
            self.controller.manual("extend", self.time)
        self.time += 0.11
        state = self.controller.tick(self.time)
        self.assertEqual(state["action"], "stop")

    def test_manual_pulse_cannot_ignore_watchdog_or_long_duration(self):
        self.feed(seconds=0.3)
        with self.assertRaises(ValueError):
            self.controller.manual("extend", self.time, duration=9.0)
        self.controller.manual("extend", self.time, duration=0.3)
        self.time += 0.41
        self.assertEqual(self.controller.tick(self.time)["state"], "STALE")

    def test_configuration_validation_and_reference_preservation(self):
        self.calibrated()
        reference = self.controller.snapshot()["reference"]
        with self.assertRaises(ValueError):
            self.controller.update_config({"upper_ratio": 1.02}, self.time)
        with self.assertRaises(ValueError):
            self.controller.update_config({"unknown": 1}, self.time)
        with self.assertRaises(ValueError):
            self.controller.update_config({"max_speed": float("nan")}, self.time)
        state = self.controller.update_config({"max_speed": 0.2}, self.time)
        self.assertEqual(state["action"], "stop")
        self.assertEqual(state["mode"], "paused")
        self.assertEqual(state["reference"], reference)

    def test_snapshot_cannot_modify_controller_reference(self):
        self.calibrated()
        state = self.controller.snapshot()
        state["reference"]["zones"][4] = 999
        state["config"]["max_speed"] = 999
        self.assertEqual(self.controller.snapshot()["reference"]["zones"][4], 40)
        self.assertEqual(self.controller.snapshot()["config"]["max_speed"], 0.35)

    def test_late_valid_frame_does_not_silently_resume(self):
        self.calibrated()
        self.time += 0.5
        state = self.controller.observe(BASE, self.time)
        self.assertEqual(state["state"], "STALE")
        self.assertEqual(state["mode"], "paused")
        self.assertEqual(state["action"], "stop")

    def test_new_reference_requires_new_stable_window_after_motion(self):
        self.feed(seconds=1.7)
        self.controller.manual("extend", self.time)
        self.feed(seconds=0.25)
        self.assertFalse(self.controller.snapshot()["reference_ready"])
        with self.assertRaises(ValueError):
            self.controller.capture_reference(self.time)


if __name__ == "__main__":
    unittest.main()
