"""Targeted synthetic fault cases; no hardware or human validation claims."""
from copy import deepcopy
import json
import unittest

from lumbar.input import (BASELINE_FRAMES, MAX_LINE_BYTES, MatrixProcessor,
                          decode_vitac_line, empty_mapping)


def wire(**changes):
    frame = {"seq": 1, "t": 50, "base": 1, "raw": [100] * 256,
             "diff": [96] * 256, "peak": 96, "pr": 0, "pc": 0,
             "nz": 0, "sum": 24576}
    frame.update(changes)
    return json.dumps(frame)


def mapping():
    return {"version": 1, "confirmed": True,
            "zones": [{"id": index + 1, "indices": [index], "polarity": 1}
                      for index in range(8)]}


class DecoderTests(unittest.TestCase):
    def test_valid_frame_keeps_evidence_recomputes_stats(self):
        result = decode_vitac_line(wire(extra={"hardware_note": "test"}).encode())
        self.assertEqual(result["seq"], 1)
        self.assertEqual(result["device_ms"], 50)
        self.assertTrue(result["baseline_flag"])
        self.assertEqual(result["original"]["nz"], 0)
        self.assertEqual(result["firmware_stats_recomputed"]["nz"], 256)
        self.assertEqual(result["original"]["extra"]["hardware_note"], "test")

    def test_blank_and_diagnostics_are_not_frames(self):
        for value in (b"", "\r\n", " # ready\n", "# 中文提示\n"):
            self.assertIsNone(decode_vitac_line(value))

    def test_missing_raw_is_explicit_none(self):
        data = json.loads(wire())
        del data["raw"]
        self.assertIsNone(decode_vitac_line(json.dumps(data))["raw"])

    def test_rejects_wrong_type_range_and_shape(self):
        cases = [dict(seq=True), dict(seq=65536), dict(seq=-1), dict(t=2**32),
                 dict(t=1.0), dict(base=True), dict(base=2), dict(nz=True),
                 dict(diff=[0] * 255), dict(raw=[256] * 256),
                 dict(raw=[False] * 256), dict(diff=[0.0] * 256),
                 dict(raw="0"), dict(pr=16)]
        for changes in cases:
            with self.subTest(changes=str(changes)[:40]):
                with self.assertRaises(ValueError):
                    decode_vitac_line(wire(**changes))

    def test_rejects_nan_duplicate_keys_and_bad_text(self):
        bad = ["[]", "{}", "{\"seq\":1,\"seq\":2}",
               wire().replace('"seq": 1', '"seq": NaN'),
               wire(extra=float("nan")), wire(extra=float("inf")),
               wire().replace('"seq": 1', '"seq": 1e9999'),
               b"\xff\n", "{bad json", wire() + wire()]
        for value in bad:
            with self.subTest(value=str(value)[:40]):
                with self.assertRaises(ValueError):
                    decode_vitac_line(value)

    def test_size_cap_is_utf8_bytes(self):
        with self.assertRaises(ValueError):
            decode_vitac_line("#" + "中" * (MAX_LINE_BYTES // 3 + 1))
        with self.assertRaises(ValueError):
            decode_vitac_line(b"#" + b"x" * MAX_LINE_BYTES)

    def test_zero_peak_has_no_location(self):
        result = decode_vitac_line(wire(diff=[0] * 256, peak=0, pr=0, pc=0))
        self.assertEqual(result["firmware_stats_recomputed"]["pr"], -1)
        self.assertEqual(result["firmware_stats_recomputed"]["pc"], -1)


class MappingTests(unittest.TestCase):
    def test_default_mapping_never_invents_eight_zones(self):
        processor = MatrixProcessor()
        for _ in range(BASELINE_FRAMES):
            result = processor.consume(decode_vitac_line(wire()))
        self.assertEqual(result["values"], [None] * 8)
        self.assertFalse(result["matrix"]["mapping_ready"])
        processor.capture_zero()
        result = processor.consume(decode_vitac_line(wire(raw=[120] * 256)))
        self.assertEqual(result["values"], [None] * 8)
        self.assertEqual(result["matrix"]["diff"], [20.0] * 256)

    def test_computer_baseline_avoids_uint8_overflow(self):
        processor = MatrixProcessor(mapping())
        for _ in range(BASELINE_FRAMES):
            result = processor.consume(decode_vitac_line(wire()))
        self.assertEqual(result["values"], [None] * 8)
        baseline = processor.capture_zero()
        self.assertEqual(baseline["baseline"], [100.0] * 256)
        self.assertEqual(baseline["kind"], "empty_sensor_baseline")
        self.assertNotIn("reference", baseline)
        result = processor.consume(decode_vitac_line(wire()))
        self.assertEqual(result["values"], [0.0] * 8)
        self.assertEqual(result["matrix"]["stats"]["nz"], 0)
        self.assertEqual(result["matrix"]["stats"]["pr"], -1)
        self.assertEqual(result["matrix"]["stats"]["pc"], -1)

    def test_all_cells_nonzero_counts_256(self):
        processor = MatrixProcessor(mapping())
        for _ in range(BASELINE_FRAMES):
            processor.consume(decode_vitac_line(wire(raw=[255] * 256)))
        self.assertEqual(processor.capture_zero()["baseline"], [255.0] * 256)
        processor.reset()
        for _ in range(BASELINE_FRAMES):
            processor.consume(decode_vitac_line(wire(raw=[0] * 256)))
        processor.capture_zero()
        result = processor.consume(decode_vitac_line(wire(raw=[255] * 256, nz=0)))
        self.assertEqual(result["matrix"]["stats"]["nz"], 256)
        self.assertEqual(result["matrix"]["stats"]["sum"], 65280)

    def test_region_mean_and_negative_polarity(self):
        config = mapping()
        config["zones"][0]["indices"] = [0, 8]
        config["zones"][1]["polarity"] = -1
        processor = MatrixProcessor(config)
        for _ in range(BASELINE_FRAMES):
            processor.consume(decode_vitac_line(wire()))
        processor.capture_zero()
        raw = [100] * 256
        raw[0], raw[8], raw[1] = 130, 110, 80
        result = processor.consume(decode_vitac_line(wire(raw=raw)))
        self.assertEqual(result["values"][0], 20)
        self.assertEqual(result["values"][1], 20)
        self.assertEqual(result["matrix"]["diff"][1], 0)

    def test_background_requires_full_recent_raw_window(self):
        processor = MatrixProcessor()
        for _ in range(BASELINE_FRAMES - 1):
            processor.consume(decode_vitac_line(wire()))
        with self.assertRaises(ValueError):
            processor.capture_zero()
        processor.consume(decode_vitac_line(wire(raw=None)))
        processor.consume(decode_vitac_line(wire()))
        with self.assertRaises(ValueError):
            processor.capture_zero()

    def test_missing_raw_never_uses_firmware_diff_as_control(self):
        processor = MatrixProcessor(mapping())
        for _ in range(BASELINE_FRAMES):
            processor.consume(decode_vitac_line(wire()))
        processor.capture_zero()
        result = processor.consume(decode_vitac_line(wire(raw=None, diff=[200] * 256)))
        self.assertEqual(result["values"], [None] * 8)
        self.assertIsNone(result["matrix"]["diff"])
        self.assertEqual(result["matrix"]["firmware_diff"], [200] * 256)
        self.assertTrue(result["warnings"])

    def test_partial_or_unconfirmed_mapping_remains_unavailable(self):
        config = mapping()
        config["zones"].pop()
        self.assertFalse(MatrixProcessor(config).mapping_ready)
        config = mapping()
        config["confirmed"] = False
        self.assertFalse(MatrixProcessor(config).mapping_ready)
        self.assertEqual(len(empty_mapping()["zones"]), 8)

    def test_bad_mappings_are_rejected(self):
        configs = []
        duplicate = mapping()
        duplicate["zones"][1]["indices"] = [0]
        configs.append(duplicate)
        duplicate = mapping()
        duplicate["zones"][1]["id"] = 1
        configs.append(duplicate)
        duplicate = mapping()
        duplicate["zones"][0]["indices"] = [0, 0]
        configs.append(duplicate)
        for field, value in (("indices", [True]), ("indices", [256]),
                             ("indices", [-1]), ("indices", [1.0]),
                             ("polarity", True), ("polarity", 0), ("id", 9)):
            config = mapping()
            config["zones"][0][field] = value
            configs.append(config)
        configs.extend([{"confirmed": "true"}, {"version": True}, []])
        for config in configs:
            with self.subTest(config=str(config)[:60]):
                with self.assertRaises(ValueError):
                    MatrixProcessor(config)

    def test_reset_discards_baseline_without_changing_mapping(self):
        processor = MatrixProcessor(mapping())
        for _ in range(BASELINE_FRAMES):
            processor.consume(decode_vitac_line(wire()))
        exported = processor.capture_zero()
        exported["baseline"][0] = 0
        self.assertEqual(processor.baseline[0], 100)
        processor.reset()
        self.assertFalse(processor.baseline_ready)
        self.assertTrue(processor.mapping_ready)
        with self.assertRaises(ValueError):
            processor.capture_zero()


if __name__ == "__main__":
    unittest.main()
