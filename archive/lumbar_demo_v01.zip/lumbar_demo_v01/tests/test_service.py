"""End-to-end service checks with synthetic input and a fake monotonic clock.

No hardware connection is opened. Every session and temporary mapping copy is
created under TemporaryDirectory, never under the deliverable's sessions folder.
"""
from collections import deque
import base64
import io
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch
import zipfile

from lumbar.service import DemoService, SerialInput


PROJECT = Path(__file__).resolve().parents[1]


class FakeClock:
    def __init__(self):
        self.now = 100.0

    def __call__(self):
        return self.now

    def advance(self, seconds=0.05):
        self.now = round(self.now + seconds, 8)
        return self.now


class FakeWireConnection:
    """A byte source that makes any attempted write immediately fail the test."""
    def __init__(self, chunks):
        self.chunks = deque(chunks)
        self.writes = []
        self.closed = False

    @property
    def in_waiting(self):
        return len(self.chunks[0]) if self.chunks else 0

    def read(self, count):
        if not self.chunks or count <= 0:
            return b""
        data = self.chunks.popleft()
        result, rest = data[:count], data[count:]
        if rest:
            self.chunks.appendleft(rest)
        return result

    def write(self, value):
        self.writes.append(value)
        raise AssertionError("Read-only serial mode attempted a physical write")

    def close(self):
        self.closed = True


class ServiceTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(prefix="lumbar-service-test-")
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        (self.root / "config").mkdir()
        shutil.copyfile(PROJECT / "config" / "hardware.json", self.root / "config" / "hardware.json")
        self.clock = FakeClock()
        self.service = DemoService(self.root, clock=self.clock)
        self.addCleanup(self.service.close)

    def run_for(self, seconds):
        for _ in range(round(seconds / 0.05)):
            self.service.step(self.clock.advance())
        return self.service.state()

    def calibrate_and_enable(self):
        self.run_for(1.8)
        self.service.action({"action": "calibrate"})
        state = self.service.action({"action": "mode", "value": "auto"})
        self.assertEqual(state["controller"]["mode"], "auto")

    def track_scenario(self, scenario, expected_action):
        self.service.action({"action": "scenario", "value": scenario})
        seen_action = False
        trace = []
        for _ in range(90):
            state = self.run_for(0.05)
            control = state["controller"]
            seen_action |= control["action"] == expected_action
            trace.append((control["state"], control["action"], control["support_ratio"]))
            self.assertEqual(control["mode"], "auto", msg=str(trace[-12:]))
            if seen_action and control["state"] == "HOLD":
                self.assertGreaterEqual(control["support_ratio"], control["band"]["lower"])
                self.assertLessEqual(control["support_ratio"], control["band"]["upper"])
                return state
        self.fail(f"{scenario} did not converge after {expected_action}: {trace[-12:]}")

    def test_mock_reference_forward_and_back_complete_the_feedback_loop(self):
        self.calibrate_and_enable()
        reference = self.service.state()["controller"]["reference"]
        initial_position = self.service.state()["motor"]["position_fraction"]
        forward = self.track_scenario("forward", "extend")
        self.assertGreater(forward["motor"]["position_fraction"], initial_position)
        backward = self.track_scenario("back", "retract")
        self.assertLess(backward["motor"]["position_fraction"], forward["motor"]["position_fraction"])
        self.assertEqual(backward["controller"]["reference"], reference)
        self.assertEqual(backward["motor"]["position_origin"], "simulated")

    def test_stale_source_stops_and_recovery_requires_explicit_reenable(self):
        self.calibrate_and_enable()
        self.service.action({"action": "scenario", "value": "forward"})
        self.run_for(0.65)
        self.service.action({"action": "scenario", "value": "stale"})
        interrupted = self.run_for(0.6)
        self.assertEqual(interrupted["controller"]["state"], "STALE")
        self.assertEqual(interrupted["controller"]["mode"], "paused")
        self.assertEqual(interrupted["motor"]["applied_action"], "stop")
        self.service.action({"action": "scenario", "value": "settled"})
        restored = self.run_for(0.3)
        self.assertEqual(restored["controller"]["mode"], "paused")
        self.assertEqual(restored["motor"]["applied_action"], "stop")

    def test_record_download_and_replay_keep_origin_and_never_actuate(self):
        self.calibrate_and_enable()
        self.service.action({"action": "record_start", "participant": "SYNTHETIC_TEST"})
        session_id = self.service.state()["recording"]["session_id"]
        with self.assertRaises(ValueError):
            self.service.download(session_id)
        self.run_for(0.4)
        self.service.action({"action": "feedback", "value": "good"})
        self.run_for(0.4)
        self.service.action({"action": "record_stop"})

        listed = self.service.sessions()["sessions"]
        self.assertEqual(len(listed), 1)
        self.assertEqual(listed[0]["id"], session_id)
        self.assertEqual(listed[0]["frames"], 16)
        with zipfile.ZipFile(io.BytesIO(self.service.download(session_id))) as archive:
            metadata = json.loads(archive.read(session_id + "/session.json"))
            records = [json.loads(line) for line in archive.read(session_id + "/frames.jsonl").splitlines()]
            events = [json.loads(line) for line in archive.read(session_id + "/events.jsonl").splitlines()]
        self.assertEqual(metadata["origin"], "synthetic")
        self.assertFalse(metadata["physical_actuator_commands_sent"])
        self.assertAlmostEqual(metadata["duration_s"], 0.8)
        self.assertEqual(len(records), 16)
        self.assertTrue(all(row["data_origin"] == "synthetic" for row in records))
        self.assertTrue(all(row["elapsed_s"] >= 0 for row in records))
        self.assertEqual(records[-1]["elapsed_s"], 0.8)
        self.assertEqual([row["elapsed_s"] for row in records], sorted(row["elapsed_s"] for row in records))
        feedback = [row for row in events if row["kind"] == "feedback"]
        self.assertEqual(feedback[0]["label_type"], "user_report_not_posture_truth")

        state = self.service.action({"action": "source", "value": "replay", "session_id": session_id})
        self.assertEqual(state["source"]["kind"], "replay")
        self.assertEqual(state["source"]["original_source"]["kind"], "mock")
        self.assertFalse(state["motor"]["can_execute"])
        self.assertIsNone(state["motor"]["position_fraction"])
        self.assertEqual(state["motor"]["recorded"]["position_origin"], "simulated")
        for action in ({"action": "manual", "direction": "extend"},
                       {"action": "mode", "value": "auto"},
                       {"action": "record_start"}):
            with self.assertRaises(ValueError):
                self.service.action(action)
        ended = self.run_for(1.0)
        self.assertTrue(ended["replay"]["ended"])
        self.assertEqual(ended["zones"], records[-1]["snapshot"]["zones"])
        self.assertEqual(ended["motor"]["applied_action"], "stop")
        self.assertEqual(len(self.service.sessions()["sessions"]), 1)

    def test_replay_events_follow_recorded_time_and_exclude_other_sessions(self):
        self.service.action({"action": "record_start", "participant": "SESSION_A"})
        session_id = self.service.state()["recording"]["session_id"]
        self.run_for(0.4)
        self.service.action({"action": "feedback", "value": "good"})
        self.run_for(0.4)
        # Feedback can arrive after the final sensor frame, before recording
        # stops. It must still appear at its recorded time, without a new frame.
        self.clock.advance(0.2)
        self.service.action({"action": "feedback", "value": "too_weak"})
        self.service.action({"action": "record_stop"})
        event_path = self.root / "sessions" / session_id / "events.jsonl"
        original_events = [json.loads(line) for line in event_path.read_text(encoding="utf-8").splitlines()]
        original_feedback = [event for event in original_events if event["kind"] == "feedback"]

        self.service.action({"action": "record_start", "participant": "SESSION_B"})
        self.run_for(0.1)
        self.service.action({"action": "feedback", "value": "too_strong"})
        self.service.action({"action": "record_stop"})
        self.assertTrue(any(event.get("value") == "too_strong" for event in self.service.state()["events"]))

        initial = self.service.action({"action": "source", "value": "replay", "session_id": session_id})
        self.assertFalse(any(event["kind"] == "feedback" for event in initial["events"]))
        before = self.run_for(0.3)  # Recorded elapsed_s is 0.35 (first frame is 0.05).
        self.assertFalse(any(event["kind"] == "feedback" for event in before["events"]))
        during = self.run_for(0.1)
        self.assertEqual([event for event in during["events"] if event["kind"] == "feedback"],
                         original_feedback[:1])
        last_frame = self.run_for(0.4)
        self.assertEqual(last_frame["replay"]["index"], last_frame["replay"]["count"])
        self.assertFalse(last_frame["replay"]["ended"])
        self.assertFalse(any(event.get("value") == "too_weak" for event in last_frame["events"]))
        ended = self.run_for(0.2)
        self.assertTrue(ended["replay"]["ended"])
        self.assertEqual(ended["events"], original_events)
        self.assertFalse(any(event.get("value") == "too_strong" for event in ended["events"]))
        self.assertEqual(ended["motor"]["applied_action"], "stop")

    def test_replay_allows_missing_events_and_rejects_oversized_event_files(self):
        self.service.action({"action": "record_start"})
        session_id = self.service.state()["recording"]["session_id"]
        self.run_for(0.1)
        self.service.action({"action": "record_stop"})
        event_path = self.root / "sessions" / session_id / "events.jsonl"
        with event_path.open("wb") as handle:
            handle.truncate(5 * 1024 * 1024 + 1)
        with self.assertRaisesRegex(ValueError, "5 MiB"):
            self.service.action({"action": "source", "value": "replay", "session_id": session_id})
        self.assertEqual(self.service.state()["source"]["kind"], "mock")
        event_path.unlink()
        state = self.service.action({"action": "source", "value": "replay", "session_id": session_id})
        self.assertEqual(state["events"], [])
        ended = self.run_for(0.2)
        self.assertEqual(ended["events"], [])
        self.assertTrue(ended["replay"]["ended"])

    def test_serial_usb_batch_records_every_frame_without_hardware_output(self):
        def frame(seq):
            return json.dumps({"seq": seq, "t": seq * 50, "base": 1,
                               "raw": [seq] * 256, "diff": [0] * 256}).encode("utf-8")
        wire = b"# synthetic firmware diagnostic\n" + frame(10) + b"\nnot-json\n" + frame(11) + b"\n" + frame(12) + b"\n"
        connection = FakeWireConnection([wire])
        # Reuse the actual stream-framing implementation with an in-memory
        # connection. The patched constructor never opens a real serial port.
        serial_input = SerialInput.__new__(SerialInput)
        serial_input.connection = connection
        serial_input.port = "TEST_ONLY"
        serial_input.baud = 2_000_000
        serial_input.pending = bytearray()
        serial_input.discarding = False
        with patch("lumbar.service.SerialInput", return_value=serial_input):
            self.service.action({"action": "source", "value": "serial", "port": "TEST_ONLY"})
        self.service.action({"action": "record_start", "participant": "SYNTHETIC_WIRE_TEST"})
        state = self.run_for(0.05)
        session_id = state["recording"]["session_id"]
        self.assertEqual(state["stats"]["frames"], 3)
        self.assertEqual(state["recording"]["frame_count"], 3)
        self.assertEqual(state["stats"]["invalid_frames"], 1)
        self.assertEqual(state["source"]["kind"], "serial")
        self.assertTrue(state["source"]["read_only"])
        self.assertFalse(state["motor"]["can_execute"])
        self.assertIsNone(state["motor"]["position_fraction"])
        with self.assertRaises(ValueError):
            self.service.action({"action": "manual", "direction": "extend"})
        self.assertEqual(connection.writes, [])
        self.service.action({"action": "record_stop"})
        with zipfile.ZipFile(io.BytesIO(self.service.download(session_id))) as archive:
            records = [json.loads(line) for line in archive.read(session_id + "/frames.jsonl").splitlines()]
            raw = [json.loads(line) for line in archive.read(session_id + "/raw_wire.jsonl").splitlines()]
        self.assertEqual([row["snapshot"]["stats"]["seq"] for row in records], [10, 11, 12])
        self.assertEqual(b"".join(base64.b64decode(row["bytes"]) for row in raw), wire)
        self.assertTrue(all(row["snapshot"]["motor"]["can_execute"] is False for row in records))
        self.assertTrue(all(row["snapshot"]["matrix"]["mapping_ready"] is False for row in records))


if __name__ == "__main__":
    unittest.main()
