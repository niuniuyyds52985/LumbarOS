# Lumbar demo v0.1 API reference

Python 3.10+, standard library server, no mandatory external dependencies. Optional pyserial for READ ONLY real sensor streaming. Existing Arduino attachments are not edited. Matrix-to-eight-zone mapping remains empty until hardware confirmation. The controller is a PC reference implementation used for simulation/shadow recommendations, NOT deployed board firmware.

## Controller (`lumbar/controller.py`)

`SupportController(config: dict | None = None)`

- `observe(zones: list[float | None], now: float, *, valid: bool = True) -> dict`: feed a fresh eight-zone frame; timestamp monotonic seconds, finite nonnegative values. Returns snapshot. Keep recent stable frames for user-triggered reference capture. Z1-4 occupancy; Z5-7 lumbar feedback; Z8 auxiliary display only.
- `tick(now: float) -> dict`: freshness watchdog even when no frame arrives.
- `capture_reference(now: float) -> dict`: capture a stable recently observed window; raise ValueError with Chinese actionable message if not ready. At least 1.5 s of fresh stable occupied contact. Separate from empty baseline.
- `set_mode(mode: str, now: float) -> dict`: manual/auto/paused; auto requires reference. No auto resumption after stale, invalid, absent, contact loss or saturation/overload condition: explicit re-enable.
- `manual(direction: str, now: float, duration: float = 0.20) -> dict`: extend/retract/stop, bounded pulse, expires in tick. Applies only to requested manual mode; service disallows for real/replay.
- `update_config(changes: dict, now: float) -> dict`: validate bounded numeric settings, stop motion on changes, no silent reference modification.
- `snapshot() -> dict`: JSON serializable.
- `reset(now: float) -> dict`: discard history/reference; paused/manual default.

Snapshot keys: mode (manual/auto/paused), state (stable English identifier), state_label (Chinese), reason (Chinese), action (extend/retract/hold/stop), speed (0..1 normalized command, NOT physical speed), support_ratio (float|null), reference (null or {zones: eight values, captured_at: monotonic seconds}), reference_ready (bool), band ({lower,upper,advance_stop,return_stop}), config (all parameters).

Simulation-only defaults: lower .88, upper 1.16, advance_stop .98, return_stop 1.06, confirm_s .30, stale_s .40, max_speed .35. The controller also checks local contact/overload and limits persistent motion duration. No automatic reference adaptation. No PID/ML required. All tuning defaults are examples, not human-safe force limits.

## Server API (`run.py`, `lumbar/service.py`)

GET /api/state -> {version, source:{kind:mock|serial|replay,label,connected,read_only,detail}, zones:[{id,label,value,valid}], matrix:null|{raw:[256 ints],diff:[256 floats]|null,baseline_ready,mapping_ready}, controller:<snapshot>, motor:{can_execute,applied_action,position_fraction,position_origin:simulated|unknown}, recording:{active,session_id,frame_count,elapsed_s}, stats:{frames,invalid_frames,rate_hz,frame_age_s}, events:[{time,kind,label}], mock:{scenario}, replay:{session_id,index,count,ended}, message}

GET /api/sessions -> {sessions:[{id,origin,frames,created_at}]}
GET /api/ports -> {ports:[{device,description}],available:bool}
GET /api/download/<session_id> -> session ZIP

POST /api/action JSON {action,...} -> {ok:true,state:<state>} or HTTP 400 {ok:false,error:<Chinese>}

Actions:
- mode {value:manual|auto|paused}
- manual {direction:extend|retract|stop} (mock only)
- calibrate (personal comfort reference)
- zero (software baseline capture for serial matrix, 16 recent raw frames; user must unload sensors; no firmware 'b' write)
- scenario {value:settled|forward|back|sway|leave|stale|invalid} (mock only)
- feedback {value:too_strong|good|too_weak}
- record_start {participant:optional string}
- record_stop
- source {value:mock|serial|replay,port:optional,baud:optional,session_id:optional}
- config {values:<controller config changes>}

Real serial is input-only. No physical motor command encoder exists; null actuator always reports stopped/unknown actual position. Replay is viewing only, including historical controller decisions, never actuates or creates new live records. Source switches require recording stopped, stop requested action, clear reference and state. Logs distinguish raw input, normalized zones, proposed command, simulated applied command, original source, user feedback. Frames preserve capture metadata; replay does not create measurements.

## Frontend (`web/`)

Buildless local HTML/CSS/JS. No external fonts/CDNs. The page polls state and labels simulation, real read-only input and replay. Zones 1/2 are at the seat front, 3/4 at the seat rear, 5/6/7 on the common moving lumbar plate, and 8 on the upper backrest. Image left/right is not asserted anatomical left/right. Signal units are relative electrical response, not N. Configuration and the 16x16 raw matrix are in the expandable diagnostics panel.

## Actuator adapter (`lumbar/actuator.py`)

`ActuatorAdapter.apply(action, speed)` receives a single shared-plate request. `motor_state()` returns execution capability and observed position when available. `SimulatedDevice` is the mock implementation. `UnconnectedActuator` has no I/O and always reports `can_execute=false`; changing a configuration flag alone cannot enable hardware movement.
